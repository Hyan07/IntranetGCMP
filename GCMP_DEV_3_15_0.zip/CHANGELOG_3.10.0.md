# Versão 3.10.0 DEV

## Sistema visual e estrutura da interface

- criada a camada compartilhada `50_UI_VisualSystem.html`, carregada depois dos estilos dos módulos;
- adotada uma linguagem institucional baseada em azul-marinho, superfícies claras, verde-petróleo e dourado de apoio;
- removidos gradientes e efeitos decorativos das principais telas pela camada de compatibilidade;
- unificados raios, bordas, sombras, controles, botões, painéis, tabelas, estados e modais;
- sidebar passa a iniciar expandida, permite recolhimento explícito e mantém a preferência no navegador;
- navegação móvel continua funcionando como gaveta e fecha após a escolha da página;
- topbar e espaçamentos foram compactados para aumentar a área útil;
- Dashboard reorganizado em métricas, atalhos operacionais, alertas e atividades recentes;
- Frota e Patrimônio passam a seguir os mesmos contratos visuais do restante da intranet;
- responsividade ajustada para desktop, tablet e celulares a partir de 390 px.

## Referência Lovable

O protótipo privado `Guardião Visual` foi criado pela integração Lovable e usado como referência de hierarquia, navegação e componentes. O código React não foi copiado para o Apps Script. Os padrões aprovados foram adaptados para HTML, CSS e JavaScript existentes, preservando todas as rotas e chamadas ao servidor.

## Compatibilidade

- nenhuma rota pública foi removida;
- IDs e seletores usados pelos módulos foram preservados;
- permissões, login por MASP, planilhas e serviços do Apps Script não foram alterados;
- esta versão não exige migração de banco nem execução de instaladores.

## Validação

Passaram 19 testes automatizados, cobrindo núcleo, login, MASP, permissões, cache, Pessoal, Patrimônio, Frota, KM, manutenção, defeitos, histórico, notificações, importações e perfil.
