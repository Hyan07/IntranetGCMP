# Changelog 3.11.0 DEV

## Arquitetura

- Criado `02_SCHEMA_Registry.gs` com versionamento interno, `DATABASE_VERSION`, `BUILD_NUMBER` e registro central das estruturas de bancos, Patrimônio e Frota.
- Criado `30_REPOSITORY_Base.gs` como contrato comum para leitura, busca, inclusão, atualização e paginação de dados.
- Criado `30_REPOSITORY_Domain.gs` com fachadas iniciais para Auth, Usuários, Pessoal, Patrimônio, Frota, Escala, Mensagens, Equipamentos, Documentos e Recompensas.
- Criado `01_CORE_LoggerService.gs` para centralizar erros, stack, usuário, origem e metadados técnicos.
- Criado `02_SCHEMA_MigrationService.gs` com dry-run e confirmação explícita para futuras migrações no DEV.
- Criados `02_SCHEMA_DiagnosticRepository.gs` e `02_SCHEMA_DiagnosticService.gs` para detectar abas ausentes, colunas ausentes, colunas duplicadas, colunas extras e IDs duplicados, sem aplicar alterações.
- Movidas as regras de Dashboard, Notificações, Lookups e Configurações para Services dedicados, mantendo as rotas existentes.
- Criado `10_CONTROLLER_Routes.gs` para concentrar as rotas públicas e autenticadas fora do gateway `10_CONTROLLER_App.gs`.
- Substituído `appendRow` por escrita com `setValues` no acesso genérico e habilitada inclusão em lote no `RepositoryBase`.

## Compatibilidade

- Nenhuma regra de negócio foi alterada.
- Nenhuma tela ou rota pública foi removida.
- Nenhum instalador ou migração é executado automaticamente.
- Produção permanece fora do escopo desta versão DEV.
