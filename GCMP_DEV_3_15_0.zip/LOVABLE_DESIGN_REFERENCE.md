# Referência visual Lovable

Projeto privado: `Guardião Visual`

- Editor: https://lovable.dev/projects/61f6932d-7144-4d82-918b-0a3a7589ff89
- Prévia: https://id-preview--61f6932d-7144-4d82-918b-0a3a7589ff89.lovable.app
- Commit de referência: `99a736603b4bfce741a67bad735a7cc02541ec8d`
- Stack do protótipo: TanStack, React, TypeScript, Tailwind e componentes compatíveis com shadcn/ui
- Dados: exclusivamente fictícios e locais
- Publicação: desativada
- Banco externo: não configurado

## Como a referência foi usada

O protótipo serviu para validar:

- sidebar expandida e recolhível;
- topbar compacta;
- Dashboard operacional sem aparência de página promocional;
- métricas pequenas e escaneáveis;
- atalhos, alertas e atividades recentes;
- padrões compartilhados de toolbar, tabela, status, paginação, vazio, erro e carregamento;
- navegação da Frota com sete áreas;
- comportamento responsivo em 1440 x 900 e 390 x 844.

## Regra de implementação

A intranet oficial continua em Google Apps Script e Google Sheets. Não migrar o backend para o Lovable, não ativar Supabase e não substituir o login por MASP. Transportar apenas decisões visuais e estruturais aprovadas, adaptadas aos componentes já existentes.
