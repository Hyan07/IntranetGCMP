/** Limpeza protegida dos registros de teste antes da implantação definitiva. */

const RESET_TEST_DATA_CONFIRMATION = 'ZERAR REGISTROS DE TESTE';

function resetTestData_(context, payload) {
  requirePermission_(context, 'configuracoes.gerenciar');
  requireFields_(payload, ['confirmation', 'currentPassword']);
  if (normalizeUpper_(payload.confirmation) !== RESET_TEST_DATA_CONFIRMATION) {
    throw appError_('RESET_CONFIRMATION_INVALID', 'Digite exatamente ' + RESET_TEST_DATA_CONFIRMATION + ' para confirmar.');
  }
  if (!verifyPassword_(String(payload.currentPassword), context.user)) {
    audit_(context, 'configuracoes', 'ZERAR_REGISTROS_TESTE', '', null, null, 'NEGADO', '', 'Senha atual inválida');
    throw appError_('INVALID_PASSWORD', 'A senha atual do administrador está incorreta.');
  }

  return withScriptLock_(function () {
    const backup = criarBackupManual();
    const cleared = {};
    const plan = {
      DB_CONFIG: ['RECUPERACAO_SENHA', 'AUDITORIA', 'NOTIFICACOES'],
      DB_PERSONNEL: ['DOCUMENTOS_PESSOAS', 'HISTORICO_FUNCIONAL', 'SOLICITACOES_ATUALIZACAO'],
      DB_ASSETS: ['PATRIMONIOS', 'CAUTELAS', 'ITENS_CAUTELA', 'DEVOLUCOES', 'MANUTENCOES_PATRIMONIO', 'DOCUMENTOS_PATRIMONIO', 'HISTORICO_PATRIMONIO', 'AUDITORIA_PATRIMONIO'],
      DB_DOCUMENTS: Object.keys(INSTALLER_SCHEMA.DB_DOCUMENTS.sheets),
      DB_REWARDS: Object.keys(INSTALLER_SCHEMA.DB_REWARDS.sheets)
    };

    Object.keys(plan).forEach(function (databaseKey) {
      const spreadsheet = getSpreadsheet_(databaseKey);
      plan[databaseKey].filter(function (name, index, all) { return all.indexOf(name) === index; }).forEach(function (sheetName) {
        const sheet = spreadsheet.getSheetByName(sheetName);
        if (!sheet) return;
        cleared[databaseKey + '.' + sheetName] = resetClearSheetData_(sheet);
        invalidateDataRowsCache_(databaseKey, sheetName);
      });
    });

    resetPatrimonioSequence_();
    audit_(context, 'configuracoes', 'ZERAR_REGISTROS_TESTE', '', null, {
      backupFolderId: backup.folderId,
      registrosRemovidos: Object.keys(cleared).reduce(function (total, key) { return total + cleared[key]; }, 0),
      preservado: ['USUARIOS', 'PESSOAS', 'PERMISSOES', 'CONFIGURACOES', 'FROTA']
    }, 'SUCESSO');

    return {
      status: 'CONCLUIDO',
      backup: backup,
      registrosRemovidos: Object.keys(cleared).reduce(function (total, key) { return total + cleared[key]; }, 0),
      porAba: cleared,
      preservado: {
        usuarios: true, pessoal: true, configuracoes: true, permissoes: true,
        frotaCompleta: true, sessoes: true, categorias: true
      }
    };
  });
}

function resetClearSheetData_(sheet) {
  const rows = Math.max(0, sheet.getLastRow() - 1);
  if (!rows) return 0;
  const columns = Math.max(1, sheet.getLastColumn());
  sheet.getRange(2, 1, rows, columns).clearContent();
  return rows;
}

function resetPatrimonioSequence_() {
  try {
    const row = findOne_(PATRIMONIO_CONFIG.DATABASE, 'CONFIG_PATRIMONIO', 'Chave', 'NUMERO_CAUTELA_SEQUENCIAL');
    if (row) updateObjectAtRow_(PATRIMONIO_CONFIG.DATABASE, 'CONFIG_PATRIMONIO', row._row, {
      Valor: '1', 'Atualizado em': now_(), 'Atualizado por': 'RESET_IMPLANTACAO'
    });
  } catch (error) {
    console.warn('Não foi possível reiniciar a sequência de cautelas: ' + error.message);
  }
}
