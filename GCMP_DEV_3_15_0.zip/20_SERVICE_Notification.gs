/** Regras de negócio de notificações do usuário. */

function listUserNotifications_(context, payload) {
  const options = payload || {};
  const userId = String(context.user.ID_USUARIO || '');
  let rows = MensagemRepository_().notifications().filter(function (item) {
    const recipient = String(item.ID_USUARIO || item.DESTINATARIO || '');
    if (recipient !== userId) return false;
    if (!normalizeBoolean_(options.includeRead) && normalizeBoolean_(item.LIDA)) return false;
    if (!normalizeBoolean_(options.includeResolved) && normalizeBoolean_(item.RESOLVIDA)) return false;
    return true;
  });
  rows.sort(function (a, b) { return new Date(b.CRIADO_EM || 0).getTime() - new Date(a.CRIADO_EM || 0).getTime(); });
  const limit = Math.min(50, Math.max(1, Number(options.limit) || 30));
  const items = rows.slice(0, limit).map(function (item) {
    return {
      id: item.ID,
      title: item.TITULO || 'Notificação',
      message: item.MENSAGEM || '',
      type: item.TIPO || 'INFO',
      severity: item.GRAVIDADE || item.TIPO || 'MEDIA',
      module: item.MODULO || '',
      recordId: item.ID_REGISTRO || '',
      createdAt: item.CRIADO_EM,
      target: notificationTarget_(item)
    };
  });
  return { items: items, unread: rows.filter(function (item) { return !normalizeBoolean_(item.LIDA); }).length };
}

function readUserNotification_(context, payload) {
  requireFields_(payload, ['id']);
  const item = repositoryFindOne_(APP_CONFIG.DATABASES.CONFIG, 'NOTIFICACOES', 'ID', payload.id);
  const recipient = item ? String(item.ID_USUARIO || item.DESTINATARIO || '') : '';
  if (!item || recipient !== String(context.user.ID_USUARIO || '')) throw appError_('NOTIFICATION_NOT_FOUND', 'Notificação não encontrada.');
  if (!normalizeBoolean_(item.LIDA)) {
    MensagemRepository_().updateNotification(item._row, { LIDA: true, LIDA_EM: now_() });
  }
  return { id: item.ID, target: notificationTarget_(item) };
}

function notificationTarget_(item) {
  const moduleName = normalizeUpper_(item.MODULO || '');
  const type = normalizeUpper_(item.TIPO || '');
  const recordId = item.ID_REGISTRO || '';
  if (moduleName === 'FROTA') {
    if (type.indexOf('DEFEITO') === 0 || ['IRREGULARIDADE', 'OBSERVACAO', 'LIMPEZA', 'DOCUMENTACAO', 'EQUIPAMENTO_AUSENTE', 'OUTRO'].indexOf(type) >= 0) {
      return { page: 'viaturas', frotaTab: 'defeitos', occurrenceId: recordId };
    }
    if (type.indexOf('MANUTENCAO_DATA') === 0) return { page: 'viaturas', frotaTab: 'gerenciamento', recordId: recordId };
    if (type.indexOf('MANUTENCAO') === 0) return { page: 'viaturas', frotaTab: 'manutencoes', maintenanceId: recordId };
    if (type.indexOf('OBSERVACAO_SAIDA') === 0 || type.indexOf('OBSERVACAO_ENCERRAMENTO') === 0) return { page: 'viaturas', frotaTab: 'km', movementId: recordId };
    if (type.indexOf('PNEU') === 0 || type.indexOf('REVISAO') === 0 || type.indexOf('OLEO') === 0 || type.indexOf('SEGURO') === 0 || type.indexOf('LICENCIAMENTO') === 0) {
      return { page: 'viaturas', frotaTab: 'gerenciamento', recordId: recordId };
    }
    return { page: 'viaturas', frotaTab: 'defeitos', recordId: recordId };
  }
  if (moduleName === 'USUARIOS') return { page: 'usuarios', requestId: recordId };
  if (moduleName === 'PERFIL') return { page: 'perfil', requestId: recordId };
  if (moduleName === 'PATRIMONIO') return { page: 'patrimonio', recordId: recordId };
  if (moduleName === 'DOCUMENTOS') return { page: 'documentos', recordId: recordId };
  if (moduleName === 'RECOMPENSAS') return { page: 'recompensas', recordId: recordId };
  return { page: 'dashboard', recordId: recordId };
}
