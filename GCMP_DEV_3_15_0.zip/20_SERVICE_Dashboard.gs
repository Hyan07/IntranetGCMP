/** Regras de negócio do Dashboard. */

function getDashboard_(context) {
  const can = function (code) { return hasPermission_(context, code); };
  const cards = [];
  const alerts = [];
  const pessoalRepository = PessoalRepository_();
  const patrimonioRepository = PatrimonioRepository_();
  const frotaRepository = FrotaRepository_();
  const documentoRepository = DocumentoRepository_();
  const recompensaRepository = RecompensaRepository_();
  const configRepository = ConfigRepository_();

  if (can('pessoal.visualizar')) {
    const people = pessoalRepository.people();
    cards.push({ id: 'pessoal', label: 'Pessoas ativas', value: people.filter(function (p) { return p.STATUS === 'ATIVO'; }).length, tone: 'blue' });
  }
  if (can('PATRIMONIO_VISUALIZAR') || can('patrimonio.visualizar')) {
    const assets = patrimonioRepository.assets();
    const openCustodies = patrimonioRepository.custodies().filter(function (c) { return ['ATIVA', 'PARCIAL'].indexOf(normalizeUpper_(c.Status)) >= 0 || c.STATUS === 'ABERTA'; });
    cards.push({ id: 'patrimonio', label: 'Patrimônios', value: assets.filter(function (a) { return a.ID && normalizeBoolean_(a.Ativo); }).length, tone: 'teal' });
    cards.push({ id: 'cautelas', label: 'Cautelas abertas', value: openCustodies.length, tone: 'amber' });
    const today = now_().getTime();
    const overdue = openCustodies.filter(function (c) {
      const due = c['Previsão de Devolução'] || c.PREVISAO_DEVOLUCAO;
      return due && new Date(due).getTime() < today;
    });
    if (overdue.length) alerts.push({ type: 'warning', title: overdue.length + ' cautela(s) vencida(s)', module: 'patrimonio' });
  }
  if (can('FROTA_ACESSAR') && getScriptProperties_().getProperty(FROTA_CONFIG.SPREADSHEET_PROPERTY)) {
    const vehicles = frotaRepository.readAll('VIATURAS').filter(function (v) { return frotaUpper_(v.ATIVO || 'SIM') !== 'NAO'; });
    const openMovements = frotaRepository.readAll('MOVIMENTACOES_KM').filter(function (m) { return frotaUpper_(m.STATUS) === 'ABERTA'; });
    const pendingDefects = frotaRepository.readAll('DEFEITOS_VIATURAS').filter(function (d) {
      return frotaUpper_(d.ATIVO || 'SIM') !== 'NAO' && ['RESOLVIDO', 'CANCELADO'].indexOf(frotaUpper_(d.STATUS_DEFEITO)) < 0;
    });
    cards.push({ id: 'viaturas', label: 'Viaturas disponíveis', value: vehicles.filter(function (v) { return frotaUpper_(v.STATUS) === 'DISPONIVEL'; }).length, tone: 'green' });
    cards.push({ id: 'turnos', label: 'Movimentações abertas', value: openMovements.length, tone: 'purple' });
    if (pendingDefects.length) alerts.push({
      type: pendingDefects.some(function (d) { return frotaUpper_(d.GRAVIDADE) === 'VIATURA_SEM_CONDICOES_DE_USO'; }) ? 'danger' : 'warning',
      title: pendingDefects.length + ' defeito(s) pendente(s) na frota',
      module: 'viaturas',
      frotaTab: 'defeitos'
    });
  } else if (can('viaturas.visualizar')) {
    const vehicles = repositoryReadAll_(APP_CONFIG.DATABASES.VEHICLES, 'VIATURAS');
    const openShifts = repositoryReadAll_(APP_CONFIG.DATABASES.VEHICLES, 'TURNOS').filter(function (s) { return s.STATUS === 'ABERTO'; });
    cards.push({ id: 'viaturas', label: 'Viaturas disponíveis', value: vehicles.filter(function (v) { return v.STATUS === 'DISPONIVEL'; }).length, tone: 'green' });
    cards.push({ id: 'turnos', label: 'Viaturas em serviço', value: openShifts.length, tone: 'purple' });
    openShifts.filter(function (s) { return now_().getTime() - new Date(s.INICIO_EM).getTime() > 18 * 3600000; })
      .forEach(function (s) { alerts.push({ type: 'danger', title: 'Turno aberto há mais de 18h: ' + s.PREFIXO, module: 'viaturas', frotaTab: 'km', recordId: s.ID_TURNO || '' }); });
  }
  if (can('documentos.visualizar')) {
    const docs = documentoRepository.documents().filter(function (d) { return d.STATUS !== 'INATIVO'; });
    const inThirtyDays = addHours_(now_(), 24 * 30).getTime();
    const expiring = docs.filter(function (d) {
      const due = toDate_(d.VENCIMENTO, true);
      return due && due.getTime() >= now_().getTime() && due.getTime() <= inThirtyDays;
    });
    cards.push({ id: 'documentos', label: 'Documentos', value: docs.length, tone: 'slate' });
    if (expiring.length) alerts.push({ type: 'warning', title: expiring.length + ' documento(s) vencem em até 30 dias', module: 'documentos' });
  }
  if (can('recompensas.visualizar')) {
    const rewards = recompensaRepository.requests();
    const inProgress = rewards.filter(function (r) { return ['RASCUNHO', 'ENVIADO', 'EM_ANALISE', 'PARECER'].indexOf(r.STATUS) >= 0; });
    cards.push({ id: 'recompensas', label: 'Pedidos em andamento', value: inProgress.length, tone: 'rose' });
  }
  if (can('pessoal.editar')) {
    try {
      const pendingUpdates = repositoryReadAll_(APP_CONFIG.DATABASES.PERSONNEL, PROFILE_UPDATE_SHEET).filter(function (item) { return normalizeUpper_(item.STATUS) === 'PENDENTE'; });
      if (pendingUpdates.length) alerts.push({ type: 'warning', title: pendingUpdates.length + ' atualização(ões) cadastral(is) aguardando aprovação', module: 'usuarios' });
    } catch (error) {
      if (error.code !== 'SHEET_NOT_FOUND') console.warn('Não foi possível consultar solicitações cadastrais: ' + error.message);
    }
  }
  const recent = hasPermission_(context, 'auditoria.visualizar')
    ? sortByDateDesc_(configRepository.audit(), 'DATA_HORA').slice(0, 8).map(function (item) {
      return { at: item.DATA_HORA, module: item.MODULO, action: item.ACAO, result: item.RESULTADO, masp: formatMasp_(item.MASP) };
    })
    : [];
  return { cards: cards, alerts: alerts.slice(0, 8), recent: recent, generatedAt: now_() };
}
