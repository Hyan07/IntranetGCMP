/** Identidade institucional e incorporação segura do brasão. */

function institutionBranding_() {
  const logoUrl = getRuntimeConfig_('LOGO_URL', '');
  let logoDataUrl = '';
  try {
    const blob = institutionLogoBlob_(logoUrl);
    if (blob) {
      const contentType = blob.getContentType() || 'image/png';
      logoDataUrl = 'data:' + contentType + ';base64,' + Utilities.base64Encode(blob.getBytes());
    }
  } catch (error) {
    console.warn('Não foi possível incorporar o brasão: ' + error.message);
  }
  return { logoUrl: logoUrl, logoDataUrl: logoDataUrl };
}

function institutionLogoBlob_(configuredValue) {
  const value = normalizeText_(configuredValue || getRuntimeConfig_('LOGO_URL', ''));
  if (!value) return null;
  if (/^data:image\//i.test(value)) {
    const match = value.match(/^data:(image\/[a-z0-9.+-]+);base64,(.+)$/i);
    if (!match) return null;
    return Utilities.newBlob(Utilities.base64Decode(match[2]), match[1], 'brasao-gcmp');
  }
  const driveId = institutionDriveFileId_(value);
  if (!driveId) return null;
  const blob = DriveApp.getFileById(driveId).getBlob();
  const contentType = blob.getContentType() || '';
  if (contentType && contentType.indexOf('image/') !== 0) throw new Error('O arquivo configurado como brasão não é uma imagem.');
  return blob.setName('brasao-gcmp');
}

function institutionDriveFileId_(value) {
  const text = String(value || '').trim();
  const patterns = [/\/d\/([a-zA-Z0-9_-]{15,})/, /[?&]id=([a-zA-Z0-9_-]{15,})/, /^([a-zA-Z0-9_-]{20,})$/];
  for (let index = 0; index < patterns.length; index += 1) {
    const match = text.match(patterns[index]);
    if (match) return match[1];
  }
  return '';
}
