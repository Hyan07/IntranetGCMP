import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';

const root = path.resolve(import.meta.dirname, '..');
const context = vm.createContext({
  console,
  PATRIMONIO_CONFIG: { DATABASE: 'ASSETS' },
  normalizeUpper_: value => String(value || '').trim().toUpperCase(),
  normalizeBoolean_: value => value === true || String(value || '').toLowerCase() === 'true',
  normalizeMasp_: value => String(value || '').replace(/\D/g, ''),
  patrimonioTemPermissao_: (auth, code) => Boolean(auth?.permissions?.includes(code)),
  readAll_: () => [
    { ID: 'C1', Status: 'ATIVA', 'Tipo de Cautela': 'COMUM', 'Data da Cautela': '2026-07-13', 'Hora da Cautela': '10:00:00' },
    { ID: 'C2', Status: 'ATIVA', 'Tipo de Cautela': 'ADMINISTRATIVA', 'Data da Cautela': '2026-07-13', 'Hora da Cautela': '11:00:00' }
  ],
  repositoryReadAll_: () => [
    { ID: 'C1', Status: 'ATIVA', 'Tipo de Cautela': 'COMUM', 'Data da Cautela': '2026-07-13', 'Hora da Cautela': '10:00:00' },
    { ID: 'C2', Status: 'ATIVA', 'Tipo de Cautela': 'ADMINISTRATIVA', 'Data da Cautela': '2026-07-13', 'Hora da Cautela': '11:00:00' }
  ],
  searchRows_: rows => rows,
  paginate_: rows => ({ items: rows, total: rows.length, page: 1, pages: 1 }),
  patrimonioCustodyClient_: row => ({ id: row.ID, type: row['Tipo de Cautela'] }),
  appError_: (code, message) => Object.assign(new Error(message), { code })
});
new vm.Script(fs.readFileSync(path.join(root, '45_PATRIMONIO_Cautelas.gs'), 'utf8'), { filename: '45_PATRIMONIO_Cautelas.gs' }).runInContext(context);

context.__types = vm.runInContext(`[
  patrimonioTipoCautela_({}),
  patrimonioTipoCautela_({'Tipo de Cautela':'COMUM'}),
  patrimonioTipoCautela_({'Tipo de Cautela':'administrativa'})
]`, context);
assert.deepEqual(Array.from(context.__types), ['COMUM', 'COMUM', 'ADMINISTRATIVA']);
assert.equal(vm.runInContext("patrimonioPodeGerenciarCautelaAdministrativa_({permissions:[]})", context), false);
assert.equal(vm.runInContext("patrimonioPodeGerenciarCautelaAdministrativa_({permissions:['CAUTELA_ADMINISTRATIVA_GERENCIAR']})", context), true);
context.__regular = vm.runInContext("patrimonioCautelasListar_({permissions:['CAUTELA_VISUALIZAR_ATIVAS']},{}).items", context);
context.__administrative = vm.runInContext("patrimonioCautelasListar_({permissions:['CAUTELA_ADMINISTRATIVA_GERENCIAR']},{}).items", context);
context.__both = vm.runInContext("patrimonioCautelasListar_({permissions:['CAUTELA_VISUALIZAR_ATIVAS','CAUTELA_ADMINISTRATIVA_GERENCIAR']},{}).items", context);
assert.deepEqual(Array.from(context.__regular, item => item.id), ['C1'], 'Usuário comum não pode receber cautela administrativa na listagem/descautelamento.');
assert.deepEqual(Array.from(context.__administrative, item => item.id), ['C2']);
assert.deepEqual(Array.from(context.__both, item => item.id), ['C2', 'C1']);

console.log('OK: tipo, permissão e isolamento da cautela administrativa validados.');
