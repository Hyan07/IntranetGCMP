import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';

const root = path.resolve(import.meta.dirname, '..');
const context = vm.createContext({ console });
for (const name of ['00_CORE_Config.gs', '01_CORE_Utils.gs', '10_CONTROLLER_App.gs', '20_SERVICE_Notification.gs']) {
  new vm.Script(fs.readFileSync(path.join(root, name), 'utf8'), { filename: name }).runInContext(context);
}

context.__notification = { MODULO: 'FROTA', TIPO: 'DEFEITO_PENDENTE', ID_REGISTRO: 'D1' };
assert.deepEqual(
  JSON.parse(vm.runInContext('JSON.stringify(notificationTarget_(__notification))', context)),
  { page: 'viaturas', frotaTab: 'defeitos', occurrenceId: 'D1' }
);

context.__notification = { MODULO: 'FROTA', TIPO: 'MANUTENCAO_7D', ID_REGISTRO: 'M1' };
assert.deepEqual(
  JSON.parse(vm.runInContext('JSON.stringify(notificationTarget_(__notification))', context)),
  { page: 'viaturas', frotaTab: 'manutencoes', maintenanceId: 'M1' }
);

context.__notification = { MODULO: 'perfil', TIPO: 'SUCESSO', ID_REGISTRO: 'S1' };
assert.deepEqual(
  JSON.parse(vm.runInContext('JSON.stringify(notificationTarget_(__notification))', context)),
  { page: 'perfil', requestId: 'S1' }
);

const scripts = fs.readFileSync(path.join(root, '50_UI_Scripts.html'), 'utf8');
const fleetUi = fs.readFileSync(path.join(root, '70_UI_FROTA_JavaScript.html'), 'utf8');
assert.match(scripts, /data-open-notification/);
assert.match(scripts, /intranet\.frota\.target/);
assert.match(fleetUi, /Tratar na manutenção/);
assert.match(fleetUi, /focusOccurrenceId/);

console.log('OK: notificações abrem o módulo, a aba e o registro correspondente.');
