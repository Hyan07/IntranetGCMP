import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

const installerSource=fs.readFileSync(new URL('../02_SCHEMA_Installer.gs',import.meta.url),'utf8');
const patrimonioSource=fs.readFileSync(new URL('../45_PATRIMONIO_Instalador.gs',import.meta.url),'utf8');
const permissionSource=fs.readFileSync(new URL('../20_SERVICE_Permission.gs',import.meta.url),'utf8');
const legacy=['patrimonio.visualizar','patrimonio.cadastrar','patrimonio.editar','patrimonio.excluir','patrimonio.realizar_cautela','patrimonio.receber_devolucao','patrimonio.consultar_historico'];

const catalogBlock=installerSource.match(/const PERMISSION_CATALOG[\s\S]*?\n\]\);/)?.[0]||'';
legacy.forEach(code=>assert.ok(!catalogBlock.includes(`['${code}'`),`${code} não deve voltar ao catálogo principal`));
assert.match(patrimonioSource,/patrimonioMigrarPermissoes_\(\);\s*const permissionCleanup = patrimonioConsolidarPermissoes_\(\)/);

const permissions=[
  {_row:2,ID_PERMISSAO:'legacy',CODIGO:'patrimonio.visualizar',MODULO:'patrimonio',ATIVA:true},
  {_row:3,ID_PERMISSAO:'official',CODIGO:'PATRIMONIO_VISUALIZAR',MODULO:'patrimonio',ATIVA:true},
  {_row:4,ID_PERMISSAO:'duplicate',CODIGO:'PATRIMONIO_VISUALIZAR',MODULO:'patrimonio',ATIVA:true}
];
const assignments=[
  {_row:2,ID:'a1',ID_USUARIO:'u1',ID_PERMISSAO:'legacy',PERMITIDO:true},
  {_row:3,ID:'a2',ID_USUARIO:'u1',ID_PERMISSAO:'official',PERMITIDO:true},
  {_row:4,ID:'a3',ID_USUARIO:'u2',ID_PERMISSAO:'duplicate',PERMITIDO:true}
];
let nextRow=5;
const context={
  console,APP_CONFIG:{DATABASES:{CONFIG:'DB_CONFIG'}},
  normalizeBoolean_:value=>value===true||String(value).toUpperCase()==='TRUE',
  readAll_:(db,sheet)=>(sheet==='PERMISSOES'?permissions:assignments).map(row=>({...row})),
  updateObjectAtRow_:(db,sheet,rowNumber,patch)=>{const rows=sheet==='PERMISSOES'?permissions:assignments,current=rows.find(row=>row._row===rowNumber);Object.assign(current,patch);return{...current};},
  appendObject_:(db,sheet,record)=>{const saved={...record,_row:nextRow++};assignments.push(saved);return{...saved};},
  uuid_:()=>`id-${nextRow}`,now_:()=>new Date('2026-07-14T12:00:00Z'),
  CacheService:{getScriptCache:()=>({remove:()=>{}})}
};
vm.createContext(context);vm.runInContext(patrimonioSource,context);
const result=vm.runInContext('patrimonioConsolidarPermissoes_()',context);
assert.equal(permissions.find(row=>row.ID_PERMISSAO==='legacy').ATIVA,false);
assert.equal(permissions.find(row=>row.ID_PERMISSAO==='official').ATIVA,true);
assert.equal(permissions.find(row=>row.ID_PERMISSAO==='duplicate').ATIVA,false);
assert.ok(assignments.some(row=>row.ID_USUARIO==='u2'&&row.ID_PERMISSAO==='official'&&row.PERMITIDO===true));
assert.equal(result.legacyDeactivated,1);
assert.equal(result.duplicatesDeactivated,1);
assert.equal(result.assignmentsMigrated,1);

const catalogContext={normalizeBoolean_:context.normalizeBoolean_};vm.createContext(catalogContext);vm.runInContext(permissionSource,catalogContext);
const visible=vm.runInContext('activeCanonicalPermissions_',catalogContext)(permissions.map(row=>({...row,ATIVA:true})));
assert.deepEqual(Array.from(visible,item=>item.CODIGO),['PATRIMONIO_VISUALIZAR']);

console.log('OK: permissões antigas e duplicadas do Patrimônio são ocultadas, migradas e desativadas sem perder concessões.');
