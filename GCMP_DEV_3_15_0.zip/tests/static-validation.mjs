import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';

const root = path.resolve(import.meta.dirname, '..');
const files = fs.readdirSync(root);
const gsFiles = files.filter((name) => name.endsWith('.gs')).sort();
const htmlFiles = files.filter((name) => name.endsWith('.html')).sort();
const failures = [];

function assert(condition, message) {
  if (!condition) failures.push(message);
}

const gsBaseNames = new Set(gsFiles.map((name) => path.basename(name, '.gs')));
const htmlBaseNames = new Set(htmlFiles.map((name) => path.basename(name, '.html')));
const conflictingBaseNames = [...gsBaseNames].filter((name) => htmlBaseNames.has(name));
assert(conflictingBaseNames.length === 0, `O Apps Script não aceita .gs e .html com o mesmo nome: ${conflictingBaseNames.join(', ')}`);

const architectureFiles = [
  '00_CORE_Config.gs',
  '00_CORE_DevEnvironment.gs',
  '10_CONTROLLER_Routes.gs',
  '02_SCHEMA_Registry.gs',
  '30_REPOSITORY_Base.gs',
  '30_REPOSITORY_Domain.gs',
  '01_CORE_LoggerService.gs',
  '02_SCHEMA_MigrationService.gs',
  '02_SCHEMA_MigrationRepository.gs',
  '02_SCHEMA_DiagnosticRepository.gs',
  '02_SCHEMA_DiagnosticService.gs',
  '20_SERVICE_PagePayload.gs',
];
for (const name of architectureFiles) assert(gsFiles.includes(name), `Arquivo arquitetural ausente: ${name}`);

['20_SERVICE_PessoalImportacao.gs', '40_FROTA_Importacao.gs', '45_PATRIMONIO_ImportacaoInicial.gs'].forEach((name) => {
  assert(!gsFiles.includes(name), `Arquivo de importação removido não deve voltar ao pacote: ${name}`);
});

const layerPrefixPattern = /^\d{2}_[A-Z]+(?:_[A-Z]+)?_/;
const invalidGsPrefixes = gsFiles.filter((name) => !layerPrefixPattern.test(name));
const invalidHtmlPrefixes = htmlFiles.filter((name) => !layerPrefixPattern.test(name));
assert(invalidGsPrefixes.length === 0, `Arquivos .gs fora do padrão de prefixo/camada: ${invalidGsPrefixes.join(', ')}`);
assert(invalidHtmlPrefixes.length === 0, `Arquivos .html fora do padrão de prefixo/camada: ${invalidHtmlPrefixes.join(', ')}`);
assert(gsFiles.some((name) => name.startsWith('20_SERVICE_')) && gsFiles.some((name) => name.startsWith('30_REPOSITORY_')), 'Services e Repositories devem permanecer em blocos separados.');
assert(htmlFiles.some((name) => name.startsWith('70_UI_FROTA_')) && htmlFiles.some((name) => name.startsWith('65_UI_PATRIMONIO_')), 'Telas de módulos devem permanecer em blocos UI por domínio.');

for (const name of gsFiles) {
  const source = fs.readFileSync(path.join(root, name), 'utf8');
  try { new vm.Script(source, { filename: name }); }
  catch (error) { failures.push(`${name}: ${error.message}`); }
}

const combinedServer = gsFiles.map((name) => fs.readFileSync(path.join(root, name), 'utf8')).join('\n');
try { new vm.Script(combinedServer, { filename: 'combined-server.gs' }); }
catch (error) { failures.push(`Servidor combinado: ${error.message}`); }
assert(!combinedServer.includes('.appendRow('), 'Inclusões devem usar escrita por intervalo com setValues, não appendRow.');
[
  'instalarModuloFrota',
  'instalarModuloPatrimonio',
  'instalarAtualizacaoPerfilUsuarios',
  'importarUsuariosEPessoal',
  'importarDadosPlanilhaAntigaFrota',
  'importarPatrimonioPlanilhasIniciais',
  'FROTA_IMPORTACAO_LEGADA_BASE64',
  'PATRIMONIO_IMPORTACAO_INICIAL_BASE64'
].forEach((name) => {
  assert(!combinedServer.includes(name), `Instalador específico ou importador removido ainda está no servidor: ${name}`);
});
const legacyAccessPattern = /\b(readAll_|findOne_|findMany_|appendObject_|updateObjectAtRow_|upsertBy_|softDeleteBy_|frotaLerTodos_|frotaEncontrar_|frotaAcrescentarMuitos_|frotaAcrescentar_|frotaAtualizar_|frotaPaginarReversoEmLotes_)\s*\(/g;
const legacyAccessAllowed = new Set(['01_CORE_Utils.gs', '30_REPOSITORY_Base.gs', '30_REPOSITORY_Domain.gs', '40_FROTA_Repository.gs', '02_SCHEMA_DiagnosticRepository.gs', '02_SCHEMA_Installer.gs', '40_FROTA_Instalador.gs', '45_PATRIMONIO_Instalador.gs', '02_SCHEMA_ResetService.gs']);
for (const name of gsFiles) {
  if (legacyAccessAllowed.has(name)) continue;
  const matches = fs.readFileSync(path.join(root, name), 'utf8').match(legacyAccessPattern);
  assert(!matches, `${name} deve acessar dados pelo RepositoryBase ou Repository de domínio; chamadas legadas: ${[...new Set(matches || [])].join(', ')}`);
}
const directSheetPattern = /\bSpreadsheetApp\b|\.getSheetByName\s*\(|\bgetRange\s*\(|\.appendRow\s*\(|\bsetValue\s*\(/g;
const directSheetAllowed = new Set(['01_CORE_Utils.gs', '30_REPOSITORY_Base.gs', '40_FROTA_Repository.gs', '02_SCHEMA_DiagnosticRepository.gs', '02_SCHEMA_MigrationRepository.gs', '02_SCHEMA_Installer.gs', '40_FROTA_Instalador.gs', '45_PATRIMONIO_Instalador.gs', '02_SCHEMA_ResetService.gs']);
for (const name of gsFiles) {
  if (directSheetAllowed.has(name)) continue;
  const matches = fs.readFileSync(path.join(root, name), 'utf8').match(directSheetPattern);
  assert(!matches, `${name} não deve acessar Google Sheets diretamente; use Repository. Ocorrências: ${[...new Set(matches || [])].join(', ')}`);
}

const clientScriptFiles = htmlFiles.filter((name) => /^\s*<script>[\s\S]*<\/script>\s*$/.test(fs.readFileSync(path.join(root, name), 'utf8')));
for (const name of clientScriptFiles) {
  const clientSource = fs.readFileSync(path.join(root, name), 'utf8').replace(/^\s*<script>\s*/, '').replace(/\s*<\/script>\s*$/, '');
  try { new vm.Script(clientSource, { filename: name }); }
  catch (error) { failures.push(`${name}: ${error.message}`); }
}

const index = fs.readFileSync(path.join(root, '50_UI_Index.html'), 'utf8');
const includes = [...index.matchAll(/include\('([^']+)'\)/g)].map((match) => match[1]);
for (const include of includes) assert(htmlFiles.includes(`${include}.html`), `Include ausente: ${include}.html`);
assert(includes.includes('50_UI_VisualSystem'), 'O Index deve carregar a camada visual compartilhada.');
assert(includes.indexOf('50_UI_VisualSystem') > includes.indexOf('70_UI_FROTA_Styles'), 'A camada visual compartilhada deve ser carregada depois dos estilos dos módulos.');
const visualSystem = fs.readFileSync(path.join(root, '50_UI_VisualSystem.html'), 'utf8');
assert(visualSystem.includes('.sidebar.is-collapsed') && visualSystem.includes('.frota-hero') && visualSystem.includes('.patrimonio-stat'), 'O sistema visual deve cobrir shell, Frota e Patrimônio.');
const appShell = fs.readFileSync(path.join(root, '50_UI_AppShell.html'), 'utf8');
const scripts = fs.readFileSync(path.join(root, '50_UI_Scripts.html'), 'utf8');
assert(appShell.includes('id="sidebar-pin"') && scripts.includes('setSidebarCollapsed') && scripts.includes('intranet.sidebar.collapsed'), 'A sidebar deve permitir recolhimento persistente.');
const dashboardPage = fs.readFileSync(path.join(root, '51_UI_DashboardPage.html'), 'utf8');
assert((dashboardPage.match(/id="dashboard-shortcuts"/g) || []).length === 1 && dashboardPage.includes('dashboard-activity-panel'), 'O Dashboard deve manter atalhos e atividades na estrutura operacional.');

const frotaPage = fs.readFileSync(path.join(root, '70_UI_FROTA_Page.html'), 'utf8');
const frotaTabs = [...frotaPage.matchAll(/data-frota-tab="([^"]+)"/g)].map((match) => match[1]);
assert(frotaTabs.length === 7, `A interface da Frota deve possuir sete abas; foram encontradas ${frotaTabs.length}.`);
assert(!frotaTabs.includes('pneus'), 'A aba visual de Pneus não deve existir.');
assert(!includes.some((name) => /PneusPage/i.test(name)), 'A página de Pneus não deve ser carregada pelo Index.');
const kmPage = fs.readFileSync(path.join(root, '70_UI_FROTA_KmPage.html'), 'utf8');
assert(kmPage.includes('data-km-driver') && kmPage.includes('Condutor responsável'), 'A tela de KM deve destacar o nome do condutor.');
const historyPage = fs.readFileSync(path.join(root, '70_UI_FROTA_HistoricoPage.html'), 'utf8');
assert(historyPage.includes('data-history-print'), 'O Histórico da Frota deve possuir o botão de impressão.');
const frotaJavaScript = fs.readFileSync(path.join(root, '70_UI_FROTA_JavaScript.html'), 'utf8');
assert(frotaJavaScript.includes("api('frota.historico.relatorio'") && frotaJavaScript.includes('@page{size:A4 landscape'), 'A impressão do histórico deve usar o relatório institucional em A4 horizontal.');
const frotaTabButtons = [...frotaPage.matchAll(/<button[^>]+data-frota-tab="([^"]+)"[^>]*>/g)];
assert(frotaTabButtons.every(match => /data-frota-permission(?:s)?=/.test(match[0])), 'Todas as abas da Frota devem declarar permissão de acesso.');

const patrimonioPage = fs.readFileSync(path.join(root, '65_UI_PATRIMONIO_Page.html'), 'utf8');
const patrimonioTabs = [...patrimonioPage.matchAll(/data-patrimonio-tab="([^"]+)"/g)].map(match => match[1]);
assert(patrimonioTabs.length === 9, `A interface de Patrimônio deve possuir nove abas; foram encontradas ${patrimonioTabs.length}.`);
assert(patrimonioTabs.includes('cautela-administrativa') && patrimonioPage.includes('CAUTELA_ADMINISTRATIVA_GERENCIAR'), 'A cautela administrativa deve possuir aba protegida por permissão própria.');
const patrimonioClient = fs.readFileSync(path.join(root, '65_UI_PATRIMONIO_JavaScript.html'), 'utf8');
const returnV2 = patrimonioClient.slice(patrimonioClient.indexOf('async function renderReturnFormV2'), patrimonioClient.indexOf('function renderReturnItemsV2'));
const custodyV2 = patrimonioClient.slice(patrimonioClient.indexOf('async function renderCustodyFormV2'), patrimonioClient.indexOf('async function renderReturnFormV2'));
assert(patrimonioClient.includes('Gaveta da cautela') && patrimonioClient.includes('patrimonio-receiver-search'), 'A cautela deve possuir pesquisa de recebedor e gaveta de equipamentos.');
assert(custodyV2.includes('excludeInternalCode: true') && !custodyV2.includes("localMatches(item,['code'"), 'A pesquisa de equipamentos da cautela não deve usar o código interno.');
assert(custodyV2.includes('data-draft-notes') && custodyV2.includes('Observações cadastradas'), 'A gaveta deve evidenciar os dados e permitir observações específicas da entrega.');
assert(patrimonioClient.includes("type: administrative?'ADMINISTRATIVA':'COMUM'") && patrimonioClient.includes('availableOnly: true, administrative, excludeInternalCode: true, query'), 'A interface deve registrar e pesquisar cautelas administrativas de forma explícita.');
assert(patrimonioClient.includes('type="datetime-local"') && patrimonioClient.includes('patrimonio-indefinite'), 'A cautela deve oferecer prazo em horas e opção indeterminada.');
assert(returnV2.includes('quartermasterMasp') && returnV2.includes('quartermasterPassword'), 'O descautelamento deve autenticar o intendente que recebe os itens.');
assert(returnV2.includes('readonly aria-readonly="true"') && returnV2.includes('O MASP não pode ser alterado ou apagado'), 'O MASP do intendente deve permanecer preenchido e bloqueado no descautelamento.');
assert(!returnV2.includes('return-photo') && !returnV2.includes('payload.photo'), 'O descautelamento novo não deve solicitar nem enviar Foto/URL.');
assert(patrimonioClient.includes('patrimonio.cautela.termosImpressao') && patrimonioClient.includes('Imprimir resultados'), 'A Auditoria deve pesquisar e imprimir termos de cautela.');
assert(patrimonioClient.includes('data-audit-section="terms"') && patrimonioClient.includes('data-audit-section="events"'), 'A Auditoria deve separar Termos de cautela e Eventos em subabas.');
assert(patrimonioClient.includes('eventsLoaded=false') && patrimonioClient.includes('await loadTerms();'), 'Os eventos da Auditoria devem ser carregados somente quando a subaba for aberta.');
assert(patrimonioClient.includes('navigationId !== local.navigationId') && patrimonioClient.includes("local.tab !== 'painel'"), 'Respostas antigas não devem sobrescrever a aba atual nem provocar erro de innerHTML.');
assert(patrimonioClient.includes("api('patrimonio.cautela.enviarEmail'") && patrimonioClient.includes('hideLoading();'), 'O envio do termo por e-mail deve ocorrer depois que o registro liberar a interface.');
const patrimonioService = fs.readFileSync(path.join(root, '45_PATRIMONIO_Service.gs'), 'utf8');
assert(patrimonioService.includes("const code = current ? normalizeUpper_(current.Código || current.ID) : recordId"), 'O código interno de novo patrimônio deve ser o próprio ID gerado.');
const patrimonioCustodies = fs.readFileSync(path.join(root, '45_PATRIMONIO_Cautelas.gs'), 'utf8');
assert(patrimonioCustodies.includes('MailApp.sendEmail') && patrimonioCustodies.includes('patrimonioEnviarTermoCautelaEmail_'), 'O termo de cautela deve ser enviado ao e-mail do recebedor.');
assert(patrimonioClient.includes('<th>Observações</th>') && patrimonioCustodies.includes('Observações gerais:') && patrimonioCustodies.includes('assetNotes'), 'O termo impresso e enviado deve apresentar as observações dos equipamentos e da cautela.');
assert(patrimonioCustodies.includes('inlineImages') && patrimonioCustodies.includes('cid:brasao'), 'O e-mail do termo deve incorporar o brasão institucional quando configurado.');
assert(patrimonioCustodies.includes('CAUTELA_ADMINISTRATIVA_GERENCIAR') && patrimonioCustodies.includes("'Tipo de Cautela': custodyType"), 'O servidor deve gravar o tipo e proteger cautelas administrativas por permissão.');
const profilePage = fs.readFileSync(path.join(root, '51_UI_ProfilePage.html'), 'utf8');
const profileService = fs.readFileSync(path.join(root, '20_SERVICE_Profile.gs'), 'utf8');
assert(profilePage.includes('data-profile-custody-tab="regular"') && profilePage.includes('data-profile-custody-tab="administrative"'), 'Minha Conta deve separar cautelas comuns e administrativas.');
assert(profileService.includes('administrativeCustodies') && profileService.includes("custody.type === 'ADMINISTRATIVA'"), 'Minha Conta deve classificar os itens do usuário pelo tipo de cautela.');
const brandingService = fs.readFileSync(path.join(root, '01_CORE_BrandingService.gs'), 'utf8');
assert(brandingService.includes('institutionDriveFileId_') && brandingService.includes('logoDataUrl'), 'O brasão deve aceitar link/ID do Google Drive e ser incorporado ao aplicativo.');

const schemaRegistrySource = fs.readFileSync(path.join(root, '02_SCHEMA_Registry.gs'), 'utf8');
const controllerRegistrySource = fs.readFileSync(path.join(root, '10_CONTROLLER_Routes.gs'), 'utf8');
const repositoryBaseSource = fs.readFileSync(path.join(root, '30_REPOSITORY_Base.gs'), 'utf8');
const domainRepositoriesSource = fs.readFileSync(path.join(root, '30_REPOSITORY_Domain.gs'), 'utf8');
const loggerSource = fs.readFileSync(path.join(root, '01_CORE_LoggerService.gs'), 'utf8');
const migrationSource = fs.readFileSync(path.join(root, '02_SCHEMA_MigrationService.gs'), 'utf8');
const diagnosticRepositorySource = fs.readFileSync(path.join(root, '02_SCHEMA_DiagnosticRepository.gs'), 'utf8');
const diagnosticServiceSource = fs.readFileSync(path.join(root, '02_SCHEMA_DiagnosticService.gs'), 'utf8');
const dashboardServiceSource = fs.readFileSync(path.join(root, '20_SERVICE_Dashboard.gs'), 'utf8');
const notificationServiceSource = fs.readFileSync(path.join(root, '20_SERVICE_Notification.gs'), 'utf8');
const lookupServiceSource = fs.readFileSync(path.join(root, '20_SERVICE_Lookup.gs'), 'utf8');
const settingsServiceSource = fs.readFileSync(path.join(root, '20_SERVICE_Settings.gs'), 'utf8');
const pagePayloadSource = fs.readFileSync(path.join(root, '20_SERVICE_PagePayload.gs'), 'utf8');
assert(controllerRegistrySource.includes('function getPublicRoutes_') && controllerRegistrySource.includes('function getAuthenticatedRoutes_'), 'O Controller Registry deve concentrar as rotas públicas e autenticadas.');
assert(schemaRegistrySource.includes('const APP_VERSION') && schemaRegistrySource.includes('const DATABASE_VERSION') && schemaRegistrySource.includes('function schemaRegistry_'), 'O Schema Registry deve centralizar versão e estrutura.');
assert(repositoryBaseSource.includes('function repositoryReadAll_') && repositoryBaseSource.includes('SCHEMA_DATABASE_FROTA_'), 'O RepositoryBase deve expor leitura comum e tratar a Frota moderna.');
['AuthRepository_', 'UserRepository_', 'PessoalRepository_', 'PatrimonioRepository_', 'FrotaRepository_', 'EscalaRepository_', 'MensagemRepository_', 'EquipamentosRepository_'].forEach((name) => {
  assert(domainRepositoriesSource.includes(`function ${name}`), `Repository de domínio ausente: ${name}`);
});
assert(loggerSource.includes('function logError_') && loggerSource.includes('OBSERVACAO_TECNICA'), 'O Logger central deve registrar stack e detalhes técnicos.');
assert(migrationSource.includes('function migrationServiceDryRun_') && migrationSource.includes('APLICAR_MIGRACOES_DEV'), 'O MigrationService deve operar com dry-run e confirmação explícita no DEV.');
assert(diagnosticRepositorySource.includes('getDisplayValues()') && diagnosticRepositorySource.includes('duplicateColumns') && diagnosticRepositorySource.includes('duplicateIds'), 'O DiagnosticRepository deve detectar colunas e IDs duplicados em bloco.');
assert(!diagnosticServiceSource.includes('SpreadsheetApp') && diagnosticServiceSource.includes('diagnosticarArquiteturaDev'), 'O DiagnosticService não deve acessar planilhas diretamente.');
assert(dashboardServiceSource.includes('function getDashboard_') && dashboardServiceSource.includes('FrotaRepository_') && dashboardServiceSource.includes('ConfigRepository_'), 'O Dashboard deve residir no Service e consumir Repositories.');
assert(notificationServiceSource.includes('function listUserNotifications_') && notificationServiceSource.includes('MensagemRepository_'), 'Notificações devem residir no Service e consumir Repository.');
assert(lookupServiceSource.includes('function getLookups_') && lookupServiceSource.includes('repositoryReadAll_'), 'Lookups devem residir no Service e passar pelo RepositoryBase.');
assert(settingsServiceSource.includes('function saveSettings_') && settingsServiceSource.includes('ConfigRepository_'), 'Configurações devem residir no Service e consumir ConfigRepository.');
assert(pagePayloadSource.includes('function getPagePayload_') && controllerRegistrySource.includes("'page.payload'"), 'Payloads consolidados por tela devem existir e estar roteados.');
assert(migrationSource.includes('NORMALIZAR_SCHEMA_DEV') && migrationSource.includes('migrationServiceStructurePlan_'), 'O MigrationService deve planejar e aplicar normalização estrutural controlada no DEV.');

const combinedClient = clientScriptFiles.map((name) => fs.readFileSync(path.join(root, name), 'utf8')).join('\n');
const frontendActions = new Set([...combinedClient.matchAll(/\bapi\('([^']+)'/g)].map((match) => match[1]));
const serverActions = new Set([
  ...[...combinedServer.matchAll(/'([^']+)': function/g)].map((match) => match[1]),
  ...[...combinedServer.matchAll(/^\s{4}([A-Za-z][A-Za-z0-9_]*): function/gm)].map((match) => match[1]),
]);
for (const action of frontendActions) assert(serverActions.has(action), `Ação usada no frontend sem rota: ${action}`);

const functionNames = [...combinedServer.matchAll(/^function\s+([A-Za-z0-9_]+)\s*\(/gm)].map((match) => match[1]);
const duplicates = functionNames.filter((name, index) => functionNames.indexOf(name) !== index);
assert(duplicates.length === 0, `Funções duplicadas: ${[...new Set(duplicates)].join(', ')}`);

try {
  const context = vm.createContext({ console });
  new vm.Script(`${combinedServer}\nglobalThis.__schema = INSTALLER_SCHEMA; globalThis.__permissions = PERMISSION_CATALOG; globalThis.__frota = FROTA_CONFIG; globalThis.__patrimonio = PATRIMONIO_CONFIG; globalThis.__registry = schemaRegistry_(); globalThis.__schemaCheck = schemaValidateRegistry_(); globalThis.__version = getVersionInfo_();`).runInContext(context);
  const schema = context.__schema;
  const registry = context.__registry;
  const schemaCheck = context.__schemaCheck;
  const version = context.__version;
  assert(version.appVersion === '3.15.0' && version.databaseVersion === '2026.07.20-dev-cleanup-005', 'O versionamento interno da arquitetura deve estar sincronizado.');
  assert(registry.databases.DB_CONFIG && registry.databases.DB_PERSONNEL && registry.databases.DB_FROTA, 'O Schema Registry deve reunir bancos centrais e Frota moderna.');
  assert(registry.databases.DB_FROTA.sheets.VIATURAS.length === context.__frota.SHEETS.VIATURAS.length, 'A Frota no Schema Registry deve usar a estrutura canônica moderna.');
  assert(registry.databases.DB_ASSETS.sheets.PATRIMONIOS.length === context.__patrimonio.SHEETS.PATRIMONIOS.length, 'O Patrimônio no Schema Registry deve usar a estrutura canônica moderna.');
  assert(schemaCheck.ok, 'O Schema Registry não deve possuir cabeçalhos duplicados ou vazios.');
  assert(Object.keys(schema).length === 6, 'O instalador deve definir seis planilhas.');
  for (const [database, definition] of Object.entries(schema)) {
    assert(Object.keys(definition.sheets).length > 0, `${database} não possui abas.`);
    for (const [sheet, headers] of Object.entries(definition.sheets)) {
      assert(headers.length === new Set(headers).size, `${database}.${sheet} possui cabeçalhos duplicados.`);
    }
  }
  const permissionCodes = context.__permissions.map((item) => item[0]);
  assert(permissionCodes.length === new Set(permissionCodes).size, 'O catálogo possui permissões duplicadas.');
  const fleet = context.__frota;
  assert(Object.keys(fleet.SHEETS).length === 8, 'O módulo Frota deve definir oito abas.');
  for (const [sheet, headers] of Object.entries(fleet.SHEETS)) {
    assert(headers.length === new Set(headers).size, `FROTA.${sheet} possui cabeçalhos duplicados.`);
  }
  const fleetPermissions = fleet.PERMISSIONS.map((item) => item[0]);
  assert(fleetPermissions.length === 22, 'O módulo Frota deve definir 22 permissões, incluindo visualização por aba.');
  assert(fleetPermissions.every((code) => permissionCodes.includes(code)), 'Todas as permissões da Frota devem existir no catálogo global.');
  const patrimony = context.__patrimonio;
  assert(Object.keys(patrimony.SHEETS).length === 7, 'O módulo Patrimônio deve definir sete abas de dados.');
  for (const [sheet, headers] of Object.entries(patrimony.SHEETS)) {
    assert(headers.length === new Set(headers).size, `PATRIMONIO.${sheet} possui cabeçalhos duplicados.`);
  }
  const patrimonyPermissions = patrimony.PERMISSIONS.map(item => item[0]);
  assert(patrimonyPermissions.every(code => permissionCodes.includes(code)), 'Todas as permissões de Patrimônio devem existir no catálogo global.');
  assert(!permissionCodes.some(code => code.startsWith('viaturas.')), 'Permissões legadas viaturas.* não devem permanecer no catálogo global.');
} catch (error) {
  failures.push(`Validação do instalador: ${error.message}`);
}

JSON.parse(fs.readFileSync(path.join(root, 'appsscript.json'), 'utf8'));

if (failures.length) {
  console.error(failures.map((failure) => `- ${failure}`).join('\n'));
  process.exit(1);
}

console.log(`OK: ${gsFiles.length} arquivos .gs, ${htmlFiles.length} arquivos .html, ${frontendActions.size} rotas usadas, 6 bancos centrais e 8 abas da Frota validados.`);
