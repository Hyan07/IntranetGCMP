import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(import.meta.dirname, '..');
const files = fs.readdirSync(root);
const read = name => fs.readFileSync(path.join(root, name), 'utf8');
const gs = files.filter(name => name.endsWith('.gs'));
const combined = gs.map(read).join('\n');

const removedFiles = [
  '20_SERVICE_PessoalImportacao.gs',
  '40_FROTA_Importacao.gs',
  '45_PATRIMONIO_ImportacaoInicial.gs'
];
for (const name of removedFiles) assert(!files.includes(name), `Arquivo de importação não deve permanecer no pacote: ${name}`);

const removedFunctions = [
  'instalarModuloFrota',
  'instalarModuloFrotaSemLock_',
  'instalarModuloPatrimonio',
  'instalarModuloPatrimonioSemLock_',
  'instalarAtualizacaoPerfilUsuarios',
  'importarUsuariosEPessoal',
  'importarPlanilhaPessoal',
  'diagnosticarImportacaoUsuariosEPessoal',
  'configurarArquivoImportacaoPessoal',
  'importarDadosPlanilhaAntigaFrota',
  'importarDadosLegadosFrota',
  'diagnosticarDadosPlanilhaAntigaFrota',
  'importarPatrimonioPlanilhasIniciais',
  'importarDadosIniciaisPatrimonio',
  'diagnosticarImportacaoPatrimonioPlanilhas',
  'listarPendenciasImportacaoPatrimonio'
];
for (const name of removedFunctions) {
  assert(!new RegExp(`function\\s+${name}\\s*\\(`).test(combined), `Função removida ainda existe: ${name}`);
}

assert(!combined.includes('FROTA_IMPORTACAO_LEGADA_BASE64'), 'Dados legados da Frota não devem permanecer embutidos.');
assert(!combined.includes('PATRIMONIO_IMPORTACAO_INICIAL_BASE64'), 'Dados iniciais de Patrimônio não devem permanecer embutidos.');
assert(combined.includes('function frotaGarantirModuloSistema_()'), 'Preparação interna da Frota deve permanecer para o instalador geral.');
assert(combined.includes('function patrimonioGarantirModuloSistema_()'), 'Preparação interna do Patrimônio deve permanecer para o instalador geral.');

const installer = read('02_SCHEMA_Installer.gs');
assert(installer.includes('frotaGarantirModuloSistema_()') && installer.includes('patrimonioGarantirModuloSistema_()'), 'O instalador geral deve preparar Frota e Patrimônio internamente.');
assert(installer.includes('SOLICITACOES_ATUALIZACAO'), 'A estrutura de aprovação da Minha Conta deve continuar no schema geral.');

const reset = read('02_SCHEMA_ResetService.gs');
const controller = read('10_CONTROLLER_Routes.gs');
const settings = read('51_UI_SettingsPage.html');
const scripts = read('50_UI_Scripts.html');
assert(controller.includes('settings.resetTestData'));
assert(settings.includes('Zerar registros de teste'));
assert(scripts.includes('ZERAR REGISTROS DE TESTE'));
assert(reset.includes('criarBackupManual()'));
assert(reset.includes('frotaCompleta: true'));
assert(!reset.includes('DB_VEHICLES: ['));
assert(reset.includes("DB_PERSONNEL: ['DOCUMENTOS_PESSOAS', 'HISTORICO_FUNCIONAL', 'SOLICITACOES_ATUALIZACAO']"));

console.log('OK: instaladores específicos públicos e importadores de dados removidos; instalador geral e limpeza protegida preservados.');
