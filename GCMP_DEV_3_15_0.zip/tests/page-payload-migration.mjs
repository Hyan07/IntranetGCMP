import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';

const root = path.resolve(import.meta.dirname, '..');
const context = vm.createContext({
  console,
  normalizeText_(value) { return String(value ?? '').trim(); },
  normalizeUpper_(value) { return String(value ?? '').trim().toUpperCase(); },
  now_() { return new Date('2026-07-20T12:00:00-03:00'); },
  listUserNotifications_() { return { items: [{ id: 'n1' }], unread: 1 }; },
  listUsers_() { return { items: [{ ID_USUARIO: 'u1' }], total: 1, page: 1, pageSize: 20, pages: 1 }; },
  hasPermission_(_context, code) { return code === 'pessoal.editar'; },
  listProfileUpdateRequests_() {
    const error = new Error('Atualização de perfil não instalada.');
    error.code = 'PROFILE_UPDATE_NOT_INSTALLED';
    throw error;
  }
});

new vm.Script(fs.readFileSync(path.join(root, '20_SERVICE_PagePayload.gs'), 'utf8'), { filename: '20_SERVICE_PagePayload.gs' }).runInContext(context);
new vm.Script(fs.readFileSync(path.join(root, '02_SCHEMA_MigrationRepository.gs'), 'utf8'), { filename: '02_SCHEMA_MigrationRepository.gs' }).runInContext(context);

const payload = vm.runInContext("getPagePayload_({}, { page: 'usuarios' })", context);
assert.equal(payload.notifications.unread, 1);
assert.equal(payload.users.total, 1);
assert.equal(payload.profileRequests.total, 0);
assert.equal(payload.profileRequests.optionalUnavailable, true);

const columns = vm.runInContext("migrationRepositoryFinalColumns_(['ID','NOME','NOME','EXTRA','EXTRA'], ['ID','NOME','STATUS'])", context);
assert.equal(JSON.stringify(columns.map(column => column.header)), JSON.stringify(['ID', 'NOME', 'STATUS', 'EXTRA', 'EXTRA_2']));
assert.equal(JSON.stringify(columns[1].indexes), JSON.stringify([1, 2]));
assert.equal(JSON.stringify(columns[3].indexes), JSON.stringify([3]));
assert.equal(JSON.stringify(columns[4].indexes), JSON.stringify([4]));
assert.equal(vm.runInContext("migrationRepositoryFirstNonBlank_(['', 'valor'], [0, 1])", context), 'valor');

console.log('OK: payload consolidado tolera abas opcionais e migração preserva duplicatas extras.');
