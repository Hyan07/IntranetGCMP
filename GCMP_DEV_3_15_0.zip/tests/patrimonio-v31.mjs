import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';

const root = path.resolve(import.meta.dirname, '..');
const rows = [
  { ID: 'C1', 'Número da Cautela': 'CAU-1', 'Grupo da Cautela': 'G1', 'ID do Patrimônio': 'P1', Patrimônio: '', Equipamento: 'Rádio', Categoria: 'Comunicação', Quantidade: 1, Unidade: 'UN', 'GCM Recebedor': 'GCM Silva', 'Matrícula do Recebedor': '1234567', Intendente: 'GCM Almeida', 'Matrícula do Intendente': '7654321', 'Data da Cautela': '2026-07-13', 'Hora da Cautela': '08:00:00', 'Previsão de Devolução': 'INDETERMINADO', 'Estado na Entrega': 'BOM', Observações: 'Observações gerais: Conferido pelo recebedor', Status: 'ATIVA' },
  { ID: 'C2', 'Número da Cautela': 'CAU-1', 'Grupo da Cautela': 'G1', 'ID do Patrimônio': 'P2', Patrimônio: 'PAT-22', Equipamento: 'Carregador', Categoria: 'Comunicação', Quantidade: 1, Unidade: 'UN', 'GCM Recebedor': 'GCM Silva', 'Matrícula do Recebedor': '1234567', Intendente: 'GCM Almeida', 'Matrícula do Intendente': '7654321', 'Data da Cautela': '2026-07-13', 'Hora da Cautela': '08:00:00', 'Previsão de Devolução': 'INDETERMINADO', 'Estado na Entrega': 'OTIMO', Status: 'ATIVA' },
  { ID: 'C3', 'Número da Cautela': 'CAU-2', 'Grupo da Cautela': 'G2', 'ID do Patrimônio': 'P3', Patrimônio: 'PAT-30', Equipamento: 'Lanterna', Categoria: 'Outros', Quantidade: 1, Unidade: 'UN', 'GCM Recebedor': 'GCM Souza', 'Matrícula do Recebedor': '1111111', Intendente: 'GCM Almeida', 'Matrícula do Intendente': '7654321', 'Data da Cautela': '2026-07-12', 'Hora da Cautela': '08:00:00', 'Previsão de Devolução': '2026-07-12T20:00:00', 'Estado na Entrega': 'BOM', Status: 'DEVOLVIDA' }
];

const context = vm.createContext({
  console,
  PATRIMONIO_CONFIG: { DATABASE: 'ASSETS' },
  readAll_: (database, sheet) => sheet === 'PATRIMONIOS' ? [
    { ID: 'P1', Patrimônio: '', Nome: 'Rádio', Marca: 'Motorola', Modelo: 'R7', 'Número de Série': 'SER-001', Observações: 'Com carregador e antena' },
    { ID: 'P2', Patrimônio: 'PAT-22', Nome: 'Carregador' }
  ] : rows,
  repositoryReadAll_: (database, sheet) => sheet === 'PATRIMONIOS' ? [
    { ID: 'P1', Patrimônio: '', Nome: 'Rádio', Marca: 'Motorola', Modelo: 'R7', 'Número de Série': 'SER-001', Observações: 'Com carregador e antena' },
    { ID: 'P2', Patrimônio: 'PAT-22', Nome: 'Carregador' }
  ] : rows,
  searchRows_: (items, query, fields) => {
    const term = String(query || '').toLowerCase();
    if (!term) return items;
    return items.filter(item => fields.some(field => String(item[field] || '').toLowerCase().includes(term)));
  },
  normalizeUpper_: value => String(value || '').trim().toUpperCase(),
  formatMasp_: value => String(value || ''),
  sha256_: value => `HASH-${value}`
});

new vm.Script(fs.readFileSync(path.join(root, '45_PATRIMONIO_Cautelas.gs'), 'utf8'), { filename: '45_PATRIMONIO_Cautelas.gs' }).runInContext(context);
context.__terms = vm.runInContext("patrimonioTermosFiltrarAgrupar_('rádio')", context);

assert.equal(context.__terms.length, 1);
assert.equal(context.__terms[0].number, 'CAU-1');
assert.equal(context.__terms[0].items.length, 2, 'Ao localizar um item, o termo deve manter todos os itens do mesmo número.');
assert.equal(context.__terms[0].indefinite, true);
assert.equal(context.__terms[0].items[0].patrimony, '', 'Item sem número patrimonial deve permanecer válido no termo.');
assert.equal(context.__terms[0].items[0].serial, 'SER-001');
assert.equal(context.__terms[0].items[0].assetNotes, 'Com carregador e antena');
assert.match(context.__terms[0].items[0].notes, /Conferido pelo recebedor/);

console.log('OK: termo completo, detalhes, observações, item sem número patrimonial e prazo indeterminado validados.');
