import assert from 'node:assert/strict';

function issue(asset, quantity) {
  assert.equal(asset.active, true);
  assert.equal(asset.custodial, true);
  const qty = asset.controlType === 'INDIVIDUAL' ? 1 : Number(quantity);
  assert.ok(Number.isInteger(qty) && qty > 0);
  assert.ok(qty <= asset.available);
  asset.available -= qty;
  asset.custody += qty;
  asset.status = asset.available > 0 ? 'PARCIALMENTE_CAUTELADO' : 'CAUTELADO';
  return { quantity: qty, returned: 0, status: 'ATIVA' };
}

function returnItem(asset, custody, quantity, result = 'DISPONIVEL') {
  const pending = custody.quantity - custody.returned;
  const qty = asset.controlType === 'INDIVIDUAL' ? 1 : Number(quantity);
  assert.ok(Number.isInteger(qty) && qty > 0 && qty <= pending);
  custody.returned += qty;
  custody.status = custody.returned === custody.quantity ? 'DEVOLVIDA' : 'PARCIAL';
  asset.custody -= qty;
  if (result === 'DISPONIVEL') asset.available += qty;
  asset.status = asset.custody > 0 ? (asset.available > 0 ? 'PARCIALMENTE_CAUTELADO' : 'CAUTELADO') : result;
}

const individual = { active: true, custodial: true, controlType: 'INDIVIDUAL', total: 1, available: 1, custody: 0, status: 'DISPONIVEL' };
const individualCustody = issue(individual, 99);
assert.deepEqual([individual.available, individual.custody, individual.status], [0, 1, 'CAUTELADO']);
returnItem(individual, individualCustody, 1);
assert.deepEqual([individual.available, individual.custody, individual.status, individualCustody.status], [1, 0, 'DISPONIVEL', 'DEVOLVIDA']);

const stock = { active: true, custodial: true, controlType: 'QUANTIDADE', total: 10, available: 10, custody: 0, status: 'DISPONIVEL' };
const stockCustody = issue(stock, 6);
assert.deepEqual([stock.available, stock.custody, stock.status], [4, 6, 'PARCIALMENTE_CAUTELADO']);
returnItem(stock, stockCustody, 2);
assert.deepEqual([stock.available, stock.custody, stock.status, stockCustody.status], [6, 4, 'PARCIALMENTE_CAUTELADO', 'PARCIAL']);
returnItem(stock, stockCustody, 4, 'DANIFICADO');
assert.deepEqual([stock.available, stock.custody, stock.status, stockCustody.status], [6, 0, 'DANIFICADO', 'DEVOLVIDA']);

assert.throws(() => issue({ ...stock, available: 1, custody: 0 }, 2));
assert.throws(() => returnItem(stock, stockCustody, 1));

console.log('OK: cautela individual, controle por quantidade, devolução parcial, avaria e bloqueios de saldo validados.');
