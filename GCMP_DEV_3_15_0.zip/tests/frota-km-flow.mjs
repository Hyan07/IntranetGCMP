import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import crypto from 'node:crypto';

const root = path.resolve(import.meta.dirname, '..');
const data = {
  VIATURAS: [{
    ID_VIATURA: 'v1', PREFIXO: 'VTR 01', PLACA: 'ABC1D23', MARCA: 'FIAT', MODELO: 'PULSE',
    TIPO: 'AUTOMOVEL', STATUS: 'DISPONIVEL', KM_ATUAL: 1000, ATIVO: 'SIM', MOVIMENTACAO_ATIVA_ID: '', OBSERVACAO_ATUAL: ''
  }],
  MOVIMENTACOES_KM: [], OBSERVACOES_VIATURAS: [], DEFEITOS_VIATURAS: [], HISTORICO_FROTA: [], PNEUS: [], MANUTENCOES: []
};

const context = vm.createContext({
  console,
  __data: data,
  Utilities: {
    getUuid: () => crypto.randomUUID(),
    formatDate: date => new Date(date).toISOString().slice(0, 10),
  },
  PropertiesService: { getScriptProperties: () => ({ getProperty: () => null }) },
  LockService: { getScriptLock: () => ({ tryLock: () => true, releaseLock: () => {} }) },
});

for (const name of ['00_CORE_Config.gs', '40_FROTA_Config.gs', '01_CORE_Utils.gs', '40_FROTA_Utils.gs']) {
  new vm.Script(fs.readFileSync(path.join(root, name), 'utf8'), { filename: name }).runInContext(context);
}

new vm.Script(`
  function requirePermission_(context, code) { if ((context.permissions || []).indexOf(code) < 0) throw appError_('FORBIDDEN', 'Sem permissão'); }
  function hasPermission_(context, code) { return (context.permissions || []).indexOf(code) >= 0; }
  function withScriptLock_(callback) { return callback(); }
  function frotaLerTodos_(sheet) { return (__data[sheet] || []).map(function (row, index) { return Object.assign({ _row: index + 2 }, row); }); }
  function frotaEncontrar_(sheet, field, value) { return frotaLerTodos_(sheet).filter(function (row) { return String(row[field]) === String(value); })[0] || null; }
  function frotaAcrescentar_(sheet, object) { __data[sheet].push(Object.assign({}, object)); return Object.assign({ _row: __data[sheet].length + 1 }, object); }
  function frotaAtualizar_(sheet, rowNumber, patch) { Object.assign(__data[sheet][rowNumber - 2], patch); return Object.assign({ _row: rowNumber }, __data[sheet][rowNumber - 2]); }
  function FrotaRepository_() { return { readAll: frotaLerTodos_, findOne: frotaEncontrar_, append: frotaAcrescentar_, update: frotaAtualizar_ }; }
  function frotaEnriquecerViaturas_(rows) { return rows; }
`).runInContext(context);

for (const name of ['40_FROTA_Service.gs', '40_FROTA_Defeitos.gs', '40_FROTA_Km.gs']) {
  new vm.Script(fs.readFileSync(path.join(root, name), 'utf8'), { filename: name }).runInContext(context);
}

new vm.Script(`
  frotaRegistrarHistorico_ = function () { return {}; };
  frotaAuditar_ = function () { return {}; };
  frotaNotificarOcorrencia_ = function () { return {}; };
  frotaCriarNotificacao_ = function () { return {}; };
`).runInContext(context);

const appContext = {
  permissions: ['FROTA_ACESSAR', 'FROTA_KM_ABRIR', 'FROTA_KM_ENCERRAR'],
  user: { ID_USUARIO: 'u1', MASP: '12345678', NOME: 'GCM Teste' },
  session: { TOKEN: 'token' },
};
context.__ctx = appContext;

function run(expression) { return vm.runInContext(expression, context); }
function assert(condition, message) { if (!condition) throw new Error(message); }

const opened = run("frotaKmAbrir_(__ctx, { vehicleId: 'v1', initialKm: 999999, kmDivergent: false, departureObservation: '' })");
assert(opened.movimentacao.CONDUTOR_MASP === '123456-78', 'O condutor deve vir da sessão no padrão 000000-00.');
assert(opened.movimentacao.KM_INICIAL_INFORMADO === 1000, 'KM sem divergência deve usar o valor do sistema.');
assert(data.VIATURAS[0].STATUS === 'EM_USO', 'A viatura deve ficar EM_USO após a abertura.');

let duplicateRejected = false;
try { run("frotaKmAbrir_(__ctx, { vehicleId: 'v1' })"); } catch { duplicateRejected = true; }
assert(duplicateRejected, 'Abertura duplicada deve ser rejeitada.');

let lowerKmRejected = false;
try { run(`frotaKmEncerrar_(__ctx, { movementId: '${opened.movimentacao.ID_MOVIMENTACAO}', finalKm: 999 })`); } catch { lowerKmRejected = true; }
assert(lowerKmRejected, 'KM final menor que o inicial deve ser rejeitado.');

const closed = run(`frotaKmEncerrar_(__ctx, { movementId: '${opened.movimentacao.ID_MOVIMENTACAO}', finalKm: 1025, closingObservation: '' })`);
assert(closed.kmPercorrido === 25, 'O KM percorrido deve ser calculado corretamente.');
assert(data.VIATURAS[0].KM_ATUAL === 1025, 'O KM atual da viatura deve ser atualizado.');
assert(data.VIATURAS[0].STATUS === 'DISPONIVEL', 'A viatura deve ser liberada após o encerramento.');
assert(data.VIATURAS[0].MOVIMENTACAO_ATIVA_ID === '', 'O vínculo da movimentação ativa deve ser limpo.');

console.log('OK: abertura, bloqueio de duplicidade, validação e encerramento de KM validados em memória.');
