import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';

const root = path.resolve(import.meta.dirname, '..');
const context = vm.createContext({ console });
new vm.Script(fs.readFileSync(path.join(root, '01_CORE_Utils.gs'), 'utf8'), { filename: '01_CORE_Utils.gs' }).runInContext(context);

context.__rows = vm.runInContext(`searchRows_([
  {NOME:'João Almeida',MASP:'00123456',SETOR:'Operacional',STATUS:'ATIVO'},
  {NOME:'Maria Souza',MASP:'00654321',SETOR:'Núcleo de Inteligência',STATUS:'ATIVO'},
  {NOME:'Almeida Júnior',MASP:'00000123',SETOR:'Operacional',STATUS:'INATIVO'}
], '"operacional" "ativo" "almeida"', ['NOME','MASP','SETOR','STATUS'])`, context);
assert.equal(context.__rows.length, 1);
assert.equal(context.__rows[0].NOME, 'João Almeida');

context.__phrase = vm.runInContext(`searchRows_([
  {NOME:'Maria Souza',SETOR:'Núcleo de Inteligência',STATUS:'ATIVO'},
  {NOME:'Núcleo',SETOR:'Inteligência',STATUS:'ATIVO'}
], '"Núcleo de Inteligência" "ATIVO"', ['NOME','SETOR','STATUS'])`, context);
assert.equal(context.__phrase.length, 1, 'A frase entre aspas deve permanecer como um único filtro.');

context.__masp = vm.runInContext(`searchRows_([{NOME:'João',MASP:'00123456'}], '"01234-56"', ['NOME','MASP'])`, context);
assert.equal(context.__masp.length, 1, 'A pesquisa composta deve manter a tolerância a zeros e hífen do MASP.');

context.__smartQuotes = vm.runInContext(`parseSearchTerms_(${JSON.stringify("“Operacional” 'ATIVO' ‘Almeida’")}).map(item => item.raw)`, context);
assert.deepEqual(Array.from(context.__smartQuotes), ['Operacional', 'ATIVO', 'Almeida']);

const service = fs.readFileSync(path.join(root, '20_SERVICE_ProfileRequest.gs'), 'utf8');
const installer = fs.readFileSync(path.join(root, '02_SCHEMA_Installer.gs'), 'utf8');
const scripts = fs.readFileSync(path.join(root, '50_UI_Scripts.html'), 'utf8');
const usersPage = fs.readFileSync(path.join(root, '51_UI_UsersPage.html'), 'utf8');
const profilePage = fs.readFileSync(path.join(root, '51_UI_ProfilePage.html'), 'utf8');
const personnelPage = fs.readFileSync(path.join(root, '51_UI_PersonnelPage.html'), 'utf8');
const userService = fs.readFileSync(path.join(root, '20_SERVICE_User.gs'), 'utf8');
const personnelService = fs.readFileSync(path.join(root, '20_SERVICE_Personnel.gs'), 'utf8');
const app = fs.readFileSync(path.join(root, '10_CONTROLLER_App.gs'), 'utf8');

assert(service.includes('SELF_APPROVAL_FORBIDDEN'));
assert(service.includes("requirePermission_(context, 'pessoal.editar')"));
assert(service.includes("STATUS: 'PENDENTE'") && service.includes("'APROVAR', 'RECUSAR'"));
assert(service.includes('repositoryUpdate_') && service.includes('HISTORICO_FUNCIONAL'));
assert(installer.includes('SOLICITACOES_ATUALIZACAO') && !installer.includes('instalarAtualizacaoPerfilUsuarios'));
assert(usersPage.includes('id="users-export"') && usersPage.includes('id="profile-requests-button"'));
assert(scripts.includes("api('users.prepareExport'") && scripts.includes("api('users.profile'"));
assert(scripts.includes('state.userLoadSequence') && scripts.includes('Filtros aplicados:'));
assert(userService.includes('prepareUsersExport_') && userService.includes('servePreparedUsersExport_'));
assert(userService.includes('downloadAsFile') && app.includes('event.parameter.downloadUsers'));
assert(scripts.includes("api('profile.requestUpdate'") && scripts.includes("api('users.reviewProfileRequest'"));
assert(profilePage.includes('Solicitar atualização') && profilePage.includes('profile-update-status'));
assert(personnelPage.includes('id="personnel-export"') && scripts.includes("api('personnel.prepareExport'"));
assert(scripts.includes('data-export-person-profile') && scripts.includes('exportPersonProfileCsv'));
assert(scripts.includes('openPersonnelExportModal') && scripts.includes('exportFieldSelector') && scripts.includes('Limpar seleção'));
assert(scripts.includes('Número do porte de arma') && scripts.includes('Validade do porte de arma'));
assert(personnelService.includes('preparePersonnelExport_') && personnelService.includes('servePreparedPersonnelExport_'));
assert(personnelService.includes("PORTE_ARMA_NUMERO: sensitiveText('PORTE_ARMA_NUMERO')"));
assert(personnelService.includes("PORTE_ARMA_VALIDADE: sensitiveDate('PORTE_ARMA_VALIDADE')"));
assert(personnelService.includes('EXPORT_FIELDS_REQUIRED') && personnelService.includes('campos: selected'));
assert(app.includes('event.parameter.downloadPersonnel'));
assert(scripts.includes('Identificação e documentos civis') && scripts.includes('Filiação e naturalidade') && scripts.includes('Controle administrativo'));
assert(scripts.includes('data-person-profile-tab="custodies"') && scripts.includes('data-person-profile-tab="history"') && scripts.includes('data-person-profile-tab="requests"'));
assert(personnelService.includes('DOCUMENTOS_PESSOAS') && personnelService.includes("FrotaRepository_().readAll('MOVIMENTACOES_KM')"));
assert(personnelService.includes('profile.history') && personnelService.includes('profile.updateRequests'));

console.log('OK: filtros entre aspas, exportação, perfil completo e aprovação administrativa validados.');
