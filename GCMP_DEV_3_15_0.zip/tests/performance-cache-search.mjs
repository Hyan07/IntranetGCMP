import assert from 'node:assert/strict';
import fs from 'node:fs';

const read = name => fs.readFileSync(new URL(`../${name}`, import.meta.url), 'utf8');
const utils = read('01_CORE_Utils.gs');
const app = read('10_CONTROLLER_App.gs');
const sessions = read('20_SERVICE_Session.gs');
const patrimonio = read('65_UI_PATRIMONIO_JavaScript.html');
const frota = read('40_FROTA_Repository.gs');

assert.match(utils, /DATA_ROWS_CACHE_SECONDS_\s*=\s*120/);
assert.match(utils, /CacheService\.getScriptCache\(\)/);
assert.match(utils, /function invalidateDataRowsCache_/);
assert.match(utils, /if \(DATA_ACCESS_RUNTIME_CACHE_\.rows\[cacheKey\]\)/);
assert.match(utils, /invalidateDataRowsCache_\(databaseKey, sheetName\)/);

assert.match(app, /function apiCall[\s\S]*resetDataAccessRuntimeCache_\(\)/);
assert.match(sessions, /activityWriteInterval/);
assert.match(sessions, /now\.getTime\(\) - lastActivity\.getTime\(\) >= activityWriteInterval/);

assert.match(patrimonio, /local\.bootstrap\.dashboard \|\| await api\('patrimonio\.painel'\)/);
assert.match(patrimonio, /receiverSearchCache: new Map\(\)/);
assert.match(patrimonio, /assetSearchCache: new Map\(\)/);
assert.match(patrimonio, /returnSearchCache: new Map\(\)/);
assert.match(patrimonio, /sequence!==local\.receiverSearchSequence/);
assert.match(patrimonio, /Digite pelo menos 2 caracteres para pesquisar/);

assert.match(frota, /getDataRowsCache_\(cacheKey\)/);
assert.match(frota, /frotaInvalidarCache_\(sheetName\)/);

console.log('OK: cache de planilhas, sessão sem escrita por tecla e pesquisas protegidas contra respostas atrasadas validados.');
