import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';

const root = path.resolve(import.meta.dirname, '..');
const context = vm.createContext({
  console,
  Utilities: {
    getUuid: () => 'uuid-test',
    formatDate: date => new Date(date).toISOString().slice(0, 10),
  },
});

for (const name of ['00_CORE_Config.gs', '40_FROTA_Config.gs', '01_CORE_Utils.gs', '40_FROTA_Utils.gs', '40_FROTA_Service.gs', '40_FROTA_Defeitos.gs', '40_FROTA_Manutencoes.gs']) {
  new vm.Script(fs.readFileSync(path.join(root, name), 'utf8'), { filename: name }).runInContext(context);
}

context.__data = {
  DEFEITOS_VIATURAS: [{
    _row: 2, ID_DEFEITO: 'D1', ID_VIATURA: 'V1', STATUS_DEFEITO: 'PENDENTE',
    GRAVIDADE: 'ALTA', DESCRICAO: 'Falha no freio', CATEGORIA: 'FREIOS', ATIVO: 'SIM',
    ID_MANUTENCAO_VINCULADA: '',
  }],
  OBSERVACOES_VIATURAS: [],
  MANUTENCOES: [],
  MOVIMENTACOES_KM: [],
};
context.__notifications = [];
context.frotaLerTodos_ = sheet => (context.__data[sheet] || []).map(item => ({ ...item }));
context.frotaEncontrar_ = (sheet, field, value) => (context.__data[sheet] || []).find(item => String(item[field]) === String(value)) || null;
context.frotaAtualizar_ = (sheet, row, patch) => {
  const item = (context.__data[sheet] || []).find(entry => entry._row === row);
  Object.assign(item, patch);
  return { ...item };
};
context.FrotaRepository_ = () => ({
  readAll: context.frotaLerTodos_,
  findOne: context.frotaEncontrar_,
  update: context.frotaAtualizar_,
});
context.frotaResolverNotificacoesReferencia_ = id => context.__notifications.push(`resolve:${id}`);
context.frotaReabrirNotificacoesReferencia_ = id => context.__notifications.push(`reopen:${id}`);
context.frotaTemMovimentacaoAberta_ = vehicleId => context.__data.MOVIMENTACOES_KM.some(item => item.ID_VIATURA === vehicleId && item.STATUS === 'ABERTA');

context.__origin = context.__data.DEFEITOS_VIATURAS[0];
context.__user = { masp: '12345678', nome: 'GCM Teste' };
context.__maintenance = {
  ID_MANUTENCAO: 'M1', ID_VIATURA: 'V1', TIPO_OCORRENCIA_ORIGEM: 'DEFEITO',
  ID_OCORRENCIA_ORIGEM: 'D1', STATUS: 'PROGRAMADA', DESCRICAO_PROBLEMA: 'Falha no freio',
  SERVICO_REALIZADO: '', OBSERVACAO: '',
};

vm.runInContext('frotaManutencaoSincronizarOrigem_(__maintenance, __origin, __user, new Date("2026-07-15T12:00:00Z"))', context);
assert.equal(context.__origin.STATUS_DEFEITO, 'EM_ANALISE');
assert.equal(context.__origin.ID_MANUTENCAO_VINCULADA, 'M1');

context.__maintenance.STATUS = 'EM_MANUTENCAO';
context.__details = { categoria: 'FREIOS', gravidade: 'VIATURA_SEM_CONDICOES_DE_USO', descricao: 'Pedal do freio sem pressão', local: 'Roda dianteira esquerda', retirada: true, complemento: '' };
vm.runInContext('frotaManutencaoSincronizarOrigem_(__maintenance, __origin, __user, new Date("2026-07-15T13:00:00Z"), __details)', context);
assert.equal(context.__origin.STATUS_DEFEITO, 'EM_REPARO');
assert.equal(context.__origin.DESCRICAO, 'Pedal do freio sem pressão');
assert.equal(context.__origin.LOCAL_DEFEITO, 'Roda dianteira esquerda');
assert.equal(context.__origin.GRAVIDADE, 'VIATURA_SEM_CONDICOES_DE_USO');
assert.equal(context.__origin.SOLICITOU_RETIRADA, 'SIM');

context.__maintenance.STATUS = 'CONCLUIDA';
context.__maintenance.SERVICO_REALIZADO = 'Sistema de freios revisado';
vm.runInContext('frotaManutencaoSincronizarOrigem_(__maintenance, __origin, __user, new Date("2026-07-15T14:00:00Z"))', context);
assert.equal(context.__origin.STATUS_DEFEITO, 'RESOLVIDO');
assert.equal(context.__origin.PROVIDENCIA_ADOTADA, 'Sistema de freios revisado');
assert.ok(context.__origin.DATA_HORA_RESOLUCAO);
assert.ok(context.__notifications.includes('resolve:D1'));

context.__maintenance.STATUS = 'CANCELADA';
vm.runInContext('frotaManutencaoSincronizarOrigem_(__maintenance, __origin, __user, new Date("2026-07-15T15:00:00Z"))', context);
assert.equal(context.__origin.STATUS_DEFEITO, 'EM_ANALISE');
assert.equal(context.__origin.ID_MANUTENCAO_VINCULADA, '');
assert.equal(context.__origin.DATA_HORA_RESOLUCAO, '');
assert.ok(context.__notifications.includes('reopen:D1'));

context.__data.MANUTENCOES = [{ ID_MANUTENCAO: 'M2', ID_VIATURA: 'V1', STATUS: 'AGUARDANDO_PECA' }];
context.__vehicle = { ID_VIATURA: 'V1', STATUS: 'INDISPONIVEL' };
assert.match(vm.runInContext('frotaMotivoBloqueioRestauracao_(__vehicle, "D1", "M1")', context), /outra manutenção ativa/i);

context.__data.MANUTENCOES[0].STATUS = 'CONCLUIDA';
assert.equal(vm.runInContext('frotaMotivoBloqueioRestauracao_(__vehicle, "D1", "M1")', context), '');

console.log('OK: ocorrência e manutenção compartilham status, resolução, cancelamento e bloqueios de disponibilidade.');
