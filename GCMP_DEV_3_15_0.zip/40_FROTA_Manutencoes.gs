/** Cadastro e acompanhamento integrado de ocorrências e manutenções. */

function frotaManutencoesListar_(context, payload) {
  frotaExigirAcesso_(context, ['FROTA_VISUALIZAR_MANUTENCOES', 'FROTA_GERENCIAR_MANUTENCOES']);
  const options = payload || {};
  let rows = frotaManutencoesEnriquecerOrigens_(FrotaRepository_().readAll('MANUTENCOES'));
  if (options.vehicleId) rows = rows.filter(function (row) { return String(row.ID_VIATURA) === String(options.vehicleId); });
  if (options.status) rows = rows.filter(function (row) { return frotaUpper_(row.STATUS) === frotaUpper_(options.status); });
  if (options.type) rows = rows.filter(function (row) { return frotaUpper_(row.TIPO_MANUTENCAO) === frotaUpper_(options.type); });
  if (options.originType) rows = rows.filter(function (row) { return frotaUpper_(row.TIPO_OCORRENCIA_ORIGEM) === frotaUpper_(options.originType); });
  rows = frotaPesquisar_(rows, options.query, [
    'PREFIXO', 'PLACA', 'TIPO_MANUTENCAO', 'CLASSIFICACAO', 'STATUS', 'OFICINA_FORNECEDOR',
    'DESCRICAO_PROBLEMA', 'SERVICO_REALIZADO', 'OBSERVACAO', 'ORIGEM_TIPO', 'ORIGEM_CATEGORIA',
    'ORIGEM_DESCRICAO', 'ORIGEM_GRAVIDADE', 'ORIGEM_STATUS'
  ]);
  rows.sort(function (a, b) { return new Date(b.DATA_ABERTURA || b.CRIADO_EM || 0).getTime() - new Date(a.DATA_ABERTURA || a.CRIADO_EM || 0).getTime(); });
  return frotaPaginar_(rows, options);
}

function frotaManutencaoObter_(context, payload) {
  frotaExigirAcesso_(context, ['FROTA_VISUALIZAR_MANUTENCOES', 'FROTA_GERENCIAR_MANUTENCOES']);
  frotaExigir_(payload, ['id']);
  const row = FrotaRepository_().findOne('MANUTENCOES', 'ID_MANUTENCAO', payload.id);
  if (!row) throw appError_('FROTA_MANUTENCAO_NAO_ENCONTRADA', 'Manutenção não encontrada.');
  return frotaSemLinha_(frotaManutencaoEnriquecerOrigem_(row));
}

function frotaManutencaoSalvar_(context, payload) {
  frotaExigirAcesso_(context, 'FROTA_GERENCIAR_MANUTENCOES');
  const input = payload || {};
  frotaExigir_(input, ['ID_VIATURA', 'TIPO_MANUTENCAO', 'CLASSIFICACAO', 'STATUS', 'DATA_ABERTURA', 'KM_ABERTURA']);
  const id = frotaTexto_(input.ID_MANUTENCAO || input.id);
  const current = id ? FrotaRepository_().findOne('MANUTENCOES', 'ID_MANUTENCAO', id) : null;
  if (id && !current) throw appError_('FROTA_MANUTENCAO_NAO_ENCONTRADA', 'Manutenção não encontrada.');
  const vehicle = frotaObterViaturaObrigatoria_(input.ID_VIATURA);
  const status = frotaValorPermitido_(input.STATUS, ['PROGRAMADA', 'AGUARDANDO_ORCAMENTO', 'AUTORIZADA', 'EM_MANUTENCAO', 'AGUARDANDO_PECA', 'CONCLUIDA', 'CANCELADA'], 'Status da manutenção');
  const user = frotaUsuario_(context);
  const timestamp = new Date();
  const labor = input.VALOR_MAO_OBRA === '' || input.VALOR_MAO_OBRA === undefined ? 0 : frotaNumero_(input.VALOR_MAO_OBRA, 'Valor de mão de obra');
  const parts = input.VALOR_PECAS === '' || input.VALOR_PECAS === undefined ? 0 : frotaNumero_(input.VALOR_PECAS, 'Valor de peças');
  const requestedOriginId = frotaTexto_(input.ID_OCORRENCIA_ORIGEM);
  const requestedOriginType = requestedOriginId
    ? frotaValorPermitido_(input.TIPO_OCORRENCIA_ORIGEM, ['DEFEITO', 'OBSERVACAO'], 'Tipo da ocorrência de origem')
    : '';
  const currentOriginId = current ? frotaTexto_(current.ID_OCORRENCIA_ORIGEM) : '';
  const currentOriginType = currentOriginId ? frotaUpper_(current.TIPO_OCORRENCIA_ORIGEM) : '';
  if (currentOriginId && (requestedOriginId !== currentOriginId || requestedOriginType !== currentOriginType)) {
    throw appError_('FROTA_ORIGEM_IMUTAVEL', 'A ocorrência de origem não pode ser trocada depois que a manutenção foi criada.');
  }
  const originId = currentOriginId || requestedOriginId;
  const originType = currentOriginType || requestedOriginType;
  const origin = originId ? frotaManutencaoObterOrigem_(originType, originId) : null;
  if (origin && String(origin.ID_VIATURA) !== String(vehicle.ID_VIATURA)) {
    throw appError_('FROTA_ORIGEM_VIATURA_DIVERGENTE', 'A ocorrência selecionada pertence a outra viatura.');
  }
  const originDetails = origin ? frotaManutencaoNormalizarDetalhesOrigem_(input, origin, originType) : null;
  const problemDescription = originDetails ? originDetails.descricao : frotaTexto_(input.DESCRICAO_PROBLEMA, 3000);
  if (!problemDescription) throw appError_('FROTA_MANUTENCAO_SEM_PROBLEMA', 'Descreva o problema ou a ocorrência que será tratada.');
  const completionDate = frotaDataSomente_(input.DATA_CONCLUSAO, true) || (status === 'CONCLUIDA' ? Utilities.formatDate(timestamp, FROTA_CONFIG.TIME_ZONE, 'yyyy-MM-dd') : '');
  const record = {
    ID_MANUTENCAO: id || Utilities.getUuid(),
    ID_VIATURA: vehicle.ID_VIATURA,
    PREFIXO: vehicle.PREFIXO,
    PLACA: vehicle.PLACA,
    TIPO_MANUTENCAO: frotaValorPermitido_(input.TIPO_MANUTENCAO, ['PREVENTIVA', 'CORRETIVA'], 'Tipo da manutenção'),
    CLASSIFICACAO: frotaUpper_(input.CLASSIFICACAO),
    STATUS: status,
    DATA_ABERTURA: frotaDataSomente_(input.DATA_ABERTURA),
    DATA_PREVISTA: frotaDataSomente_(input.DATA_PREVISTA, true),
    DATA_INICIO: frotaDataSomente_(input.DATA_INICIO, true),
    DATA_CONCLUSAO: completionDate,
    KM_ABERTURA: frotaNumero_(input.KM_ABERTURA, 'KM de abertura'),
    KM_CONCLUSAO: input.KM_CONCLUSAO === '' || input.KM_CONCLUSAO === undefined ? '' : frotaNumero_(input.KM_CONCLUSAO, 'KM de conclusão'),
    OFICINA_FORNECEDOR: frotaTexto_(input.OFICINA_FORNECEDOR, 180),
    CNPJ_CPF_FORNECEDOR: frotaTexto_(input.CNPJ_CPF_FORNECEDOR, 30).replace(/[^0-9A-Za-z./-]/g, ''),
    DESCRICAO_PROBLEMA: problemDescription,
    SERVICO_REALIZADO: frotaTexto_(input.SERVICO_REALIZADO, 3000),
    PECAS_SUBSTITUIDAS: frotaTexto_(input.PECAS_SUBSTITUIDAS, 3000),
    VALOR_MAO_OBRA: labor,
    VALOR_PECAS: parts,
    VALOR_TOTAL: labor + parts,
    PROXIMA_MANUTENCAO_DATA: frotaDataSomente_(input.PROXIMA_MANUTENCAO_DATA, true),
    PROXIMA_MANUTENCAO_KM: input.PROXIMA_MANUTENCAO_KM === '' || input.PROXIMA_MANUTENCAO_KM === undefined ? '' : frotaNumero_(input.PROXIMA_MANUTENCAO_KM, 'Próxima manutenção por KM'),
    OBSERVACAO: frotaTexto_(input.OBSERVACAO, 3000),
    CRIADO_POR_MASP: current ? current.CRIADO_POR_MASP : user.masp,
    CRIADO_POR_NOME: current ? current.CRIADO_POR_NOME : user.nome,
    CRIADO_EM: current ? current.CRIADO_EM : timestamp,
    ATUALIZADO_EM: timestamp,
    ID_OCORRENCIA_ORIGEM: originId,
    TIPO_OCORRENCIA_ORIGEM: originType
  };
  return withScriptLock_(function () {
    if (origin) frotaManutencaoValidarVinculoUnico_(record, current);
    const saved = current ? FrotaRepository_().update('MANUTENCOES', current._row, record) : FrotaRepository_().append('MANUTENCOES', record);
    const updatedOrigin = origin ? frotaManutencaoSincronizarOrigem_(saved, origin, user, timestamp, originDetails) : null;
    const vehiclePatch = { ATUALIZADO_EM: timestamp, ATUALIZADO_POR_MASP: user.masp };
    let restoreRequested = false;
    let vehicleRestored = false;
    let restoreBlockedReason = '';
    if (['EM_MANUTENCAO', 'AGUARDANDO_PECA'].indexOf(status) >= 0 && ['BAIXADA', 'INATIVA', 'SINISTRADA'].indexOf(frotaUpper_(vehicle.STATUS)) < 0) {
      vehiclePatch.STATUS = 'EM_MANUTENCAO';
    }
    if (originDetails && (originDetails.gravidade === 'VIATURA_SEM_CONDICOES_DE_USO' || originDetails.retirada) &&
      ['PROGRAMADA', 'AGUARDANDO_ORCAMENTO', 'AUTORIZADA'].indexOf(status) >= 0 &&
      ['BAIXADA', 'INATIVA', 'SINISTRADA'].indexOf(frotaUpper_(vehicle.STATUS)) < 0) {
      vehiclePatch.STATUS = 'INDISPONIVEL';
    }
    if (status === 'CONCLUIDA') {
      restoreRequested = frotaBoolean_(input.RETORNAR_DISPONIVEL) || input.RETORNAR_DISPONIVEL === undefined;
      if (restoreRequested) {
        const resolvedDefectId = originType === 'DEFEITO' ? originId : '';
        restoreBlockedReason = frotaMotivoBloqueioRestauracao_(vehicle, resolvedDefectId, saved.ID_MANUTENCAO);
        if (!restoreBlockedReason) {
          vehiclePatch.STATUS = 'DISPONIVEL';
          vehiclePatch.MOVIMENTACAO_ATIVA_ID = '';
          vehicleRestored = true;
        }
      }
      if (record.PROXIMA_MANUTENCAO_DATA) vehiclePatch.MANUTENCAO_PROXIMA_DATA = record.PROXIMA_MANUTENCAO_DATA;
      if (record.PROXIMA_MANUTENCAO_KM !== '') vehiclePatch.MANUTENCAO_PROXIMA_KM = record.PROXIMA_MANUTENCAO_KM;
      vehiclePatch.MANUTENCAO_PROXIMA_DESCRICAO = record.SERVICO_REALIZADO || record.DESCRICAO_PROBLEMA;
      if (record.KM_CONCLUSAO !== '' && Number(record.KM_CONCLUSAO) > Number(vehicle.KM_ATUAL || 0)) vehiclePatch.KM_ATUAL = record.KM_CONCLUSAO;
    }
    if (Object.keys(vehiclePatch).length > 2) FrotaRepository_().update('VIATURAS', vehicle._row, vehiclePatch);
    frotaRegistrarHistorico_(context, {
      ID_VIATURA: vehicle.ID_VIATURA, PREFIXO: vehicle.PREFIXO, PLACA: vehicle.PLACA, TIPO_ACAO: 'MANUTENCAO',
      CAMPO_ALTERADO: current ? 'ATUALIZACAO_MANUTENCAO' : 'NOVA_MANUTENCAO', VALOR_ANTERIOR: current ? frotaSemLinha_(current) : '',
      VALOR_NOVO: updatedOrigin ? { manutencao: frotaSemLinha_(saved), ocorrencia: frotaSemLinha_(updatedOrigin) } : frotaSemLinha_(saved), JUSTIFICATIVA: input.OBSERVACAO || ''
    });
    frotaAuditar_(context, current ? 'EDITAR_MANUTENCAO' : 'CADASTRAR_MANUTENCAO', saved.ID_MANUTENCAO, current, {
      manutencao: frotaSemLinha_(saved), ocorrencia: updatedOrigin ? frotaSemLinha_(updatedOrigin) : null,
      viaturaRestaurada: vehicleRestored, motivoBloqueio: restoreBlockedReason
    }, input.OBSERVACAO || '');
    const response = frotaSemLinha_(frotaManutencaoEnriquecerOrigem_(saved));
    response.RESTAURACAO_SOLICITADA = restoreRequested;
    response.VIATURA_RESTAURADA = vehicleRestored;
    response.MOTIVO_NAO_RESTAURADA = restoreBlockedReason;
    return response;
  });
}

function frotaManutencaoObterOrigem_(type, id) {
  const normalizedType = frotaValorPermitido_(type, ['DEFEITO', 'OBSERVACAO'], 'Tipo da ocorrência de origem');
  const sheetName = normalizedType === 'DEFEITO' ? 'DEFEITOS_VIATURAS' : 'OBSERVACOES_VIATURAS';
  const field = normalizedType === 'DEFEITO' ? 'ID_DEFEITO' : 'ID_OBSERVACAO';
  const origin = FrotaRepository_().findOne(sheetName, field, id);
  if (!origin) throw appError_('FROTA_OCORRENCIA_ORIGEM_NAO_ENCONTRADA', 'A ocorrência de origem não foi encontrada.');
  return origin;
}

function frotaManutencaoValidarVinculoUnico_(record, current) {
  const duplicate = FrotaRepository_().readAll('MANUTENCOES').some(function (item) {
    if (current && String(item.ID_MANUTENCAO) === String(current.ID_MANUTENCAO)) return false;
    if (frotaUpper_(item.STATUS) === 'CANCELADA') return false;
    return String(item.ID_OCORRENCIA_ORIGEM) === String(record.ID_OCORRENCIA_ORIGEM) &&
      frotaUpper_(item.TIPO_OCORRENCIA_ORIGEM) === frotaUpper_(record.TIPO_OCORRENCIA_ORIGEM);
  });
  if (duplicate) throw appError_('FROTA_OCORRENCIA_JA_VINCULADA', 'Esta ocorrência já possui uma manutenção ativa vinculada. Abra a manutenção existente para continuar o atendimento.');
}

function frotaManutencaoNormalizarDetalhesOrigem_(input, origin, type) {
  const isDefect = frotaUpper_(type) === 'DEFEITO';
  const rawDescription = input.ORIGEM_DESCRICAO !== undefined
    ? input.ORIGEM_DESCRICAO
    : (isDefect ? origin.DESCRICAO : origin.OBSERVACAO_NOVA);
  const description = frotaTexto_(rawDescription, 3000);
  if (!description) throw appError_('FROTA_OCORRENCIA_SEM_DESCRICAO', 'A descrição da ocorrência vinculada é obrigatória.');
  const hasWithdrawal = Object.prototype.hasOwnProperty.call(input, 'ORIGEM_SOLICITOU_RETIRADA');
  return {
    categoria: frotaValorPermitido_(input.ORIGEM_CATEGORIA || origin.CATEGORIA || origin.TIPO || 'OUTRO', FROTA_CONFIG.CATEGORIAS_OCORRENCIA, 'Categoria da ocorrência'),
    gravidade: frotaValorPermitido_(input.ORIGEM_GRAVIDADE || origin.GRAVIDADE || 'MEDIA', FROTA_CONFIG.GRAVIDADES, 'Gravidade da ocorrência'),
    descricao: description,
    local: isDefect ? frotaTexto_(input.ORIGEM_LOCAL !== undefined ? input.ORIGEM_LOCAL : origin.LOCAL_DEFEITO, 500) : '',
    retirada: isDefect ? (hasWithdrawal ? frotaBoolean_(input.ORIGEM_SOLICITOU_RETIRADA) : frotaBoolean_(origin.SOLICITOU_RETIRADA)) : false,
    complemento: frotaTexto_(input.ORIGEM_COMPLEMENTO !== undefined ? input.ORIGEM_COMPLEMENTO : (isDefect ? '' : origin.MOTIVO), 1500)
  };
}

function frotaManutencaoPatchDetalhesOrigem_(type, details) {
  if (!details) return {};
  if (frotaUpper_(type) === 'DEFEITO') {
    return {
      CATEGORIA: details.categoria,
      GRAVIDADE: details.gravidade,
      DESCRICAO: details.descricao,
      LOCAL_DEFEITO: details.local,
      SOLICITOU_RETIRADA: details.retirada ? 'SIM' : 'NAO'
    };
  }
  return {
    CATEGORIA: details.categoria,
    GRAVIDADE: details.gravidade,
    OBSERVACAO_NOVA: details.descricao,
    MOTIVO: details.complemento
  };
}

function frotaManutencaoSincronizarOrigem_(maintenance, origin, user, timestamp, details) {
  const type = frotaUpper_(maintenance.TIPO_OCORRENCIA_ORIGEM);
  const status = frotaUpper_(maintenance.STATUS);
  const sheetName = type === 'DEFEITO' ? 'DEFEITOS_VIATURAS' : 'OBSERVACOES_VIATURAS';
  const detailsPatch = frotaManutencaoPatchDetalhesOrigem_(type, details);
  if (status === 'CANCELADA') {
    if (String(origin.ID_MANUTENCAO_VINCULADA || '') === String(maintenance.ID_MANUTENCAO)) {
      const cancelPatch = Object.assign({}, detailsPatch, { ID_MANUTENCAO_VINCULADA: '' });
      if (type === 'DEFEITO' && frotaUpper_(origin.STATUS_DEFEITO) !== 'CANCELADO') {
        cancelPatch.STATUS_DEFEITO = 'EM_ANALISE';
        cancelPatch.DATA_HORA_RESOLUCAO = '';
        cancelPatch.PROVIDENCIA_ADOTADA = origin.PROVIDENCIA_ADOTADA || 'Manutenção vinculada cancelada; ocorrência devolvida para análise.';
      }
      const cancelledOrigin = FrotaRepository_().update(sheetName, origin._row, cancelPatch);
      if (type === 'DEFEITO' && frotaUpper_(origin.STATUS_DEFEITO) !== 'CANCELADO') frotaReabrirNotificacoesReferencia_(origin.ID_DEFEITO);
      return cancelledOrigin;
    }
    return origin;
  }
  if (type === 'OBSERVACAO') {
    return FrotaRepository_().update(sheetName, origin._row, Object.assign({}, detailsPatch, { ID_MANUTENCAO_VINCULADA: maintenance.ID_MANUTENCAO }));
  }
  const defectPatch = Object.assign({}, detailsPatch, {
    ID_MANUTENCAO_VINCULADA: maintenance.ID_MANUTENCAO,
    RESPONSAVEL_TRATAMENTO_MASP: user.masp,
    RESPONSAVEL_TRATAMENTO_NOME: user.nome,
    DATA_HORA_VISUALIZACAO: origin.DATA_HORA_VISUALIZACAO || timestamp
  });
  if (maintenance.SERVICO_REALIZADO) defectPatch.PROVIDENCIA_ADOTADA = maintenance.SERVICO_REALIZADO;
  if (maintenance.OBSERVACAO) defectPatch.OBSERVACAO_RESOLUCAO = maintenance.OBSERVACAO;
  if (['PROGRAMADA', 'AGUARDANDO_ORCAMENTO', 'AUTORIZADA'].indexOf(status) >= 0) {
    defectPatch.STATUS_DEFEITO = 'EM_ANALISE';
    defectPatch.DATA_HORA_RESOLUCAO = '';
  }
  if (['EM_MANUTENCAO', 'AGUARDANDO_PECA'].indexOf(status) >= 0) {
    defectPatch.STATUS_DEFEITO = 'EM_REPARO';
    defectPatch.DATA_HORA_RESOLUCAO = '';
  }
  if (status === 'CONCLUIDA') {
    defectPatch.STATUS_DEFEITO = 'RESOLVIDO';
    defectPatch.DATA_HORA_RESOLUCAO = timestamp;
    defectPatch.PROVIDENCIA_ADOTADA = maintenance.SERVICO_REALIZADO || origin.PROVIDENCIA_ADOTADA || 'Manutenção corretiva concluída.';
    defectPatch.OBSERVACAO_RESOLUCAO = maintenance.OBSERVACAO || maintenance.SERVICO_REALIZADO || origin.OBSERVACAO_RESOLUCAO || '';
  }
  const updatedDefect = FrotaRepository_().update(sheetName, origin._row, defectPatch);
  if (status === 'CONCLUIDA') frotaResolverNotificacoesReferencia_(origin.ID_DEFEITO);
  else frotaReabrirNotificacoesReferencia_(origin.ID_DEFEITO);
  return updatedDefect;
}

function frotaManutencoesEnriquecerOrigens_(rows) {
  const defectsById = {};
  const observationsById = {};
  const needsDefects = rows.some(function (row) { return frotaUpper_(row.TIPO_OCORRENCIA_ORIGEM) === 'DEFEITO' && row.ID_OCORRENCIA_ORIGEM; });
  const needsObservations = rows.some(function (row) { return frotaUpper_(row.TIPO_OCORRENCIA_ORIGEM) === 'OBSERVACAO' && row.ID_OCORRENCIA_ORIGEM; });
  if (needsDefects) FrotaRepository_().readAll('DEFEITOS_VIATURAS').forEach(function (row) { defectsById[String(row.ID_DEFEITO)] = row; });
  if (needsObservations) FrotaRepository_().readAll('OBSERVACOES_VIATURAS').forEach(function (row) { observationsById[String(row.ID_OBSERVACAO)] = row; });
  return rows.map(function (row) {
    const type = frotaUpper_(row.TIPO_OCORRENCIA_ORIGEM);
    const origin = type === 'DEFEITO' ? defectsById[String(row.ID_OCORRENCIA_ORIGEM)] : observationsById[String(row.ID_OCORRENCIA_ORIGEM)];
    return frotaManutencaoAplicarResumoOrigem_(row, origin, type);
  });
}

function frotaManutencaoEnriquecerOrigem_(row) {
  const id = frotaTexto_(row && row.ID_OCORRENCIA_ORIGEM);
  if (!id) return Object.assign({}, row);
  const type = frotaUpper_(row.TIPO_OCORRENCIA_ORIGEM);
  let origin = null;
  try { origin = frotaManutencaoObterOrigem_(type, id); } catch (error) { origin = null; }
  return frotaManutencaoAplicarResumoOrigem_(row, origin, type);
}

function frotaManutencaoAplicarResumoOrigem_(row, origin, type) {
  const output = Object.assign({}, row);
  if (!origin) return output;
  output.ORIGEM_TIPO = type;
  output.ORIGEM_CATEGORIA = origin.CATEGORIA || origin.TIPO || '';
  output.ORIGEM_DESCRICAO = type === 'DEFEITO' ? origin.DESCRICAO : origin.OBSERVACAO_NOVA;
  output.ORIGEM_GRAVIDADE = origin.GRAVIDADE || '';
  output.ORIGEM_SUBTIPO = type === 'OBSERVACAO' ? origin.TIPO : 'DEFEITO';
  output.ORIGEM_LOCAL = type === 'DEFEITO' ? origin.LOCAL_DEFEITO : '';
  output.ORIGEM_SOLICITOU_RETIRADA = type === 'DEFEITO' ? frotaBoolean_(origin.SOLICITOU_RETIRADA) : false;
  output.ORIGEM_COMPLEMENTO = type === 'OBSERVACAO' ? origin.MOTIVO : '';
  output.ORIGEM_PROVIDENCIA = type === 'DEFEITO' ? origin.PROVIDENCIA_ADOTADA : '';
  output.ORIGEM_RESOLUCAO = type === 'DEFEITO' ? origin.OBSERVACAO_RESOLUCAO : '';
  output.ORIGEM_STATUS = type === 'DEFEITO' ? origin.STATUS_DEFEITO : 'REGISTRADA';
  output.ORIGEM_DATA_HORA = type === 'DEFEITO' ? origin.DATA_HORA_REGISTRO : origin.DATA_HORA;
  output.ORIGEM_INFORMADO_POR_NOME = origin.INFORMADO_POR_NOME || '';
  output.ORIGEM_INFORMADO_POR_MASP = origin.INFORMADO_POR_MASP || '';
  return output;
}
