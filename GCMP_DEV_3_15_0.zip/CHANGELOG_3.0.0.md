# Versão 3.0.0

## Patrimônio e Cautelas

- oito abas internas responsivas;
- instalador idempotente `instalarModuloPatrimonio()`;
- migração não destrutiva dos dados patrimoniais antigos;
- controle individual e por quantidade;
- cautela simples ou múltipla;
- autenticação do próprio GCM recebedor usando a mesma senha do sistema;
- devolução total ou parcial, também autenticada;
- destaque permanente do nome e MASP do recebedor;
- termo imprimível, código de verificação e opção de salvar em PDF;
- histórico, auditoria sem senhas, CSV, Excel e impressão;
- categorias, subcategorias e regras configuráveis;
- permissões granulares verificadas no servidor.

## Frota 2.2.0

- acesso separado para cada área da Frota;
- abas sem permissão são ocultadas;
- rotas de consulta também bloqueiam acesso indevido no servidor;
- nova visualização específica para KM, veículos, manutenções e defeitos;
- a aba “Viaturas” foi renomeada para “Veículos”;
- permissões antigas `viaturas.*` são desativadas e deixam de aparecer no catálogo;
- descrições das permissões foram atualizadas para o módulo Frota.
