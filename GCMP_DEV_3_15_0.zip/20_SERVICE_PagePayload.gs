/** Payloads consolidados para reduzir chamadas pequenas por tela. */

function getPagePayload_(context, payload) {
  const input = payload || {};
  const page = normalizeText_(input.page || input.module || 'dashboard');
  const result = {
    page: page,
    generatedAt: now_()
  };

  if (input.includeNotifications !== false) {
    result.notifications = listUserNotifications_(context, { limit: Number(input.notificationLimit) || 30 });
  }

  if (page === 'dashboard') {
    result.dashboard = getDashboard_(context);
    return result;
  }

  if (page === 'usuarios') {
    result.users = listUsers_(context, input.list || input.users || {});
    if (hasPermission_(context, 'pessoal.editar')) {
      try {
        result.profileRequests = listProfileUpdateRequests_(context, input.profileRequests || { page: 1, pageSize: 5, status: 'PENDENTE' });
      } catch (error) {
        if (error.code !== 'PROFILE_UPDATE_NOT_INSTALLED') throw error;
        result.profileRequests = { items: [], page: 1, pageSize: 5, total: 0, pages: 1, optionalUnavailable: true };
      }
    }
    return result;
  }

  if (page === 'pessoal') {
    result.lookups = getLookups_(context);
    result.personnel = listPersonnel_(context, input.list || input.personnel || {});
    return result;
  }

  if (page === 'configuracoes') {
    result.settings = listSettings_(context);
    const selectedTab = normalizeText_(input.tab || 'general');
    if (selectedTab === 'permissions' && hasPermission_(context, 'usuarios.gerenciar_permissoes')) {
      result.bulkPermissions = getBulkPermissionData_(context);
    }
    if (selectedTab === 'audit' && hasPermission_(context, 'auditoria.visualizar')) {
      result.audit = listAudit_(context, input.audit || {});
    }
    return result;
  }

  if (page === 'perfil') {
    result.profile = getOwnProfile_(context);
    return result;
  }

  if (page === 'patrimonio') {
    result.patrimonio = patrimonioBootstrap_(context);
    return result;
  }

  if (page === 'viaturas') {
    result.frota = frotaObterBootstrap_(context);
    return result;
  }

  return result;
}
