/** Regras de negócio de configurações administrativas. */

function listSettings_(context) {
  requirePermission_(context, 'configuracoes.gerenciar');
  return ConfigRepository_().settings().map(function (row) { delete row._row; return row; });
}

function saveSettings_(context, payload) {
  requirePermission_(context, 'configuracoes.gerenciar');
  const values = payload && payload.values ? payload.values : {};
  const allowed = ['NOME_SISTEMA', 'NOME_INSTITUICAO', 'LOGO_URL', 'FAVICON_URL', 'SESSAO_HORAS', 'SESSAO_INATIVIDADE_MINUTOS', 'MAX_TENTATIVAS_LOGIN', 'BLOQUEIO_MINUTOS', 'RECUPERACAO_MINUTOS', 'EMAIL_SUPORTE'];
  const before = {};
  withScriptLock_(function () {
    Object.keys(values).forEach(function (key) {
      if (allowed.indexOf(key) < 0) return;
      const row = ConfigRepository_().findSetting(key);
      if (!row) return;
      before[key] = row.VALOR;
      repositoryUpdate_(APP_CONFIG.DATABASES.CONFIG, 'CONFIGURACOES', row._row, { VALOR: normalizeText_(values[key]), ATUALIZADO_EM: now_() });
    });
  });
  audit_(context, 'configuracoes', 'ATUALIZAR', '', before, values, 'SUCESSO');
  return listSettings_(context);
}
