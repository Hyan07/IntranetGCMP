# Intranet de Recursos Institucionais — Google Apps Script

Versão atual: **3.15.0 DEV**. O MASP utiliza o padrão único `000000-00` em cadastros, exibições e pesquisas, inclusive para dados antigos sem o zero inicial.

Projeto completo para implantação com `clasp`, usando Google Apps Script, HTML Service, Google Sheets e Google Drive.

Os arquivos estão organizados por prefixo e bloco de camada, em formato plano compatível com Apps Script: `00_CORE`, `10_CONTROLLER`, `20_SERVICE`, `30_REPOSITORY`, `40_FROTA`, `45_PATRIMONIO`, `50_UI`, `65_UI_PATRIMONIO` e `70_UI_FROTA`.

As telas da Frota usam o sufixo `Page` (por exemplo, `70_UI_FROTA_KmPage.html`) porque o Apps Script não permite que um arquivo `.gs` e um `.html` tenham o mesmo nome-base. Isso evita o erro do `clasp` “A file with this name already exists”.

## O que está incluído

- login próprio por matrícula/MASP e senha;
- senha com hash SHA-256, salt individual e segredo interno do projeto;
- bloqueio temporário após tentativas inválidas;
- sessão de 6 horas e encerramento por inatividade;
- recuperação de senha por código enviado ao e-mail cadastrado;
- permissões granulares no padrão `modulo.acao`, verificadas no servidor;
- concessão de permissões em massa na aba Administração, com seleção de usuários e acessos sem remover permissões existentes;
- cadastro de usuários e pessoas, com ficha completa da pessoa separada por dados civis, endereço, vínculo funcional, conta de acesso e históricos integrados, além de exportação CSV da lista filtrada e da ficha individual;
- perfil completo do usuário, pesquisa por múltiplos termos entre aspas e exportação CSV da lista filtrada;
- solicitação de atualização dos dados da Minha Conta, aplicada somente após aprovação de outro administrador;
- módulo Patrimônio e Cautelas com nove abas internas, cautela comum e administrativa, pesquisa de equipamentos sem o código interno, identificação detalhada dos itens entregues, observações no termo, controle individual ou por quantidade, devolução parcial e autenticação do GCM recebedor/intendente;
- módulo Frota com sete páginas internas e fluxo integrado entre Defeitos/Observações e Manutenções, incluindo abertura da oficina a partir da ocorrência, sincronização de status e liberação segura da viatura;
- tratamento centralizado: após o vínculo, categoria, gravidade, descrição, local, retirada de serviço, providência e resolução da ocorrência são editados exclusivamente na manutenção;
- sino com lista de notificações não lidas e navegação direta para o módulo, a aba e o registro correspondente, inclusive no celular;
- documentos gerais com níveis de acesso, uploads e versões;
- estrutura inicial completa para pedidos de recompensa;
- Minha Conta com cautelas comuns e administrativas separadas, sessões e alteração de senha;
- auditoria imutável das operações relevantes;
- interface SPA responsiva para computador, tablet e celular;
- cache curto com invalidação automática e pesquisas protegidas contra chamadas repetidas ou respostas atrasadas;
- menu lateral expansível ao passar o mouse e retrátil no celular;
- instalador idempotente das planilhas e pastas do Drive;
- backup manual dos seis bancos centrais e da planilha própria da Frota.
- validação arquitetural automática para impedir Services acessando Google Sheets diretamente fora dos Repositories.
- payload consolidado por página para reduzir chamadas pequenas no Dashboard, Usuários, Pessoal e Administração.
- migração estrutural DEV com dry-run, confirmação explícita e backup oculto antes de normalizar cabeçalhos.
- organização em blocos prefixados por camada, sem pastas reais, para manter compatibilidade com `clasp` e facilitar manutenção.
- pacote sem importadores embutidos de dados legados e sem instaladores públicos específicos por módulo.

## 1. Criar ou vincular o projeto pelo clasp

Se ainda não existe um projeto Apps Script:

```bash
npm install -g @google/clasp
clasp login
clasp create --type standalone --title "Intranet de Recursos GCMP"
```

Se o projeto já existe, crie o arquivo `.clasp.json` na raiz desta pasta:

```json
{
  "scriptId": "ID_DO_SEU_PROJETO_APPS_SCRIPT",
  "rootDir": "."
}
```

O modelo está em `.clasp.json.example`.

## 2. Enviar os arquivos

Dentro da pasta do projeto:

```bash
clasp push
clasp open
```

Autorize a substituição dos arquivos quando o `clasp` solicitar.

## 3. Executar o instalador

No editor do Apps Script:

1. selecione a função `instalarSistema`;
2. clique em **Executar**;
3. autorize o acesso ao Google Sheets, Google Drive e envio de e-mail;
4. aguarde a mensagem `INSTALAÇÃO CONCLUÍDA` no registro de execução;
5. copie o MASP e a senha temporária exibidos no registro.

O instalador cria automaticamente:

- a pasta `INTRANET_RECURSOS` e todas as subpastas;
- a planilha de configuração;
- a planilha de pessoal;
- a planilha de patrimônio;
- a planilha de viaturas;
- a planilha de documentos;
- a planilha de recompensas;
- a planilha `INTRANET_GCMP_FROTA`, com oito abas e todos os cabeçalhos do módulo;
- todas as abas, cabeçalhos, catálogos e permissões;
- o primeiro administrador com todas as permissões;
- o acionador de limpeza de sessões expiradas;
- o acionador diário `rotinaDiariaFrota`, para revisões, óleo, seguro, licenciamento, manutenção, pneus e defeitos.

Credencial inicial:

- MASP padrão: `000000-00`;
- a senha é gerada durante a instalação e aparece somente no registro da execução;
- o sistema exige a troca no primeiro acesso.

> Executar `instalarSistema()` novamente não apaga dados. A função repara abas, acrescenta colunas ausentes e atualiza o módulo Frota.

### Reparo estrutural controlado

As funções públicas de instalação específica por módulo e importação de dados legados foram removidas. Para atualização estrutural, use o instalador geral `instalarSistema()` ou o reparo geral `repararEstruturaSistema()` somente no ambiente adequado e após backup.

No DEV, para conferir a estrutura sem alterar dados, execute `diagnosticarArquiteturaDev()`, `diagnosticarModuloPatrimonio()`, `diagnosticarModuloFrota()` e `MigrationService_().dryRun()`.

## 4. Implantar como aplicativo da Web

No editor do Apps Script:

1. clique em **Implantar > Nova implantação**;
2. selecione **Aplicativo da Web**;
3. em **Executar como**, escolha **Eu**;
4. defina quem pode abrir o endereço conforme a política da instituição;
5. conclua a implantação e copie o endereço terminado em `/exec`.

Para o login ser totalmente independente da conta Google, a implantação precisa permitir acesso ao endereço sem exigir conta Google. Em uma instituição com Google Workspace, prefira restringir a implantação ao domínio quando isso atender aos usuários.

## 5. Primeira configuração

1. entre com o MASP `000000-00` e a senha provisória;
2. crie uma nova senha;
3. abra **Administração > Configurações gerais**;
4. ajuste nome do sistema, instituição, logomarca, tempos de sessão e e-mail de suporte;
5. cadastre as pessoas;
6. crie os usuários e vincule-os às pessoas;
7. abra o botão de escudo de cada usuário e marque as permissões necessárias.

Na Frota, `FROTA_ACESSAR` abre o módulo, mas cada área exige sua própria permissão. A tela de permissões permite liberar separadamente Lançamento de KM, Veículos, Histórico, Gerenciamento, Manutenções, Arquivos e Defeitos/observações. Permissões antigas no grupo `viaturas` são desativadas pelo instalador e não aparecem mais no catálogo.

## Funções administrativas úteis

- `instalarSistema()` — instala ou repara toda a estrutura;
- `repararEstruturaSistema()` — alias explícito para reparo;
- `obterResumoInstalacao()` — retorna os IDs configurados;
- `criarBackupManual()` — copia as seis planilhas para `INTRANET_RECURSOS/BACKUPS`;
- `cleanupExpiredSessions_()` — encerra sessões vencidas; também é executada por acionador.
- `diagnosticarModuloPatrimonio()` — confere as sete abas e todos os cabeçalhos patrimoniais;
- `diagnosticarModuloFrota()` — confere planilha, abas, colunas, pasta e triggers;
- `rotinaDiariaFrota()` — executa manualmente a verificação de alertas da Frota.

## Atualizações futuras

Depois de alterar arquivos localmente:

```bash
clasp push
```

Crie uma **nova versão da implantação** para publicar a atualização. O endereço `/exec` antigo não recebe a mudança até a implantação apontar para a nova versão. Quando houver novas abas ou colunas, execute `repararEstruturaSistema()` ou uma migração documentada e aprovada.

## Segurança operacional

- Não compartilhe a senha provisória em grupos ou documentos públicos.
- Restrinja o acesso às planilhas e à pasta institucional.
- O proprietário da implantação deve ser uma conta institucional estável.
- Não mova uploads manualmente para pastas pessoais.
- Revise periodicamente usuários ativos, permissões e auditoria.
- Execute backups antes de alterações estruturais importantes.
