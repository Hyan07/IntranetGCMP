# Versão 3.0.2 — impressão institucional do Histórico da Frota

- Adicionado o botão **Imprimir histórico** na aba Histórico da Frota.
- A impressão respeita todos os filtros aplicados na consulta.
- O relatório usa formato A4 horizontal, cabeçalho institucional, identificação do emissor, MASP, data de emissão e total de registros.
- A tabela impressa apresenta viatura, tipo de registro, campo alterado, valores anterior e novo, justificativa e responsável.
- Menus, filtros e botões são removidos automaticamente do papel e do PDF.
- Para proteger o desempenho do Web App, cada relatório apresenta até 2.000 registros, com aviso quando o resultado total ultrapassa esse limite.
