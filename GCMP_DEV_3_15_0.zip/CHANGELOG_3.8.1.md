# Versão 3.8.1

## Permissões do Patrimônio

- removidas do catálogo principal as sete permissões antigas `patrimonio.*` que repetiam ações do módulo atual;
- o instalador migra concessões antigas para os códigos oficiais antes de desativar as linhas legadas;
- linhas duplicadas com o mesmo código são consolidadas sem retirar o acesso dos usuários vinculados;
- os seletores individual e em massa exibem somente permissões ativas, atuais e únicas;
- a limpeza é não destrutiva: registros antigos permanecem na planilha com `ATIVA = false` para preservar o histórico.
