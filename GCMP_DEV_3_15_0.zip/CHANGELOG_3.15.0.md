# Changelog 3.15.0 DEV

- Removidas as funções públicas de instalação específica `instalarModuloFrota`, `instalarModuloPatrimonio` e `instalarAtualizacaoPerfilUsuarios`.
- Preservada a preparação interna de Frota e Patrimônio apenas pelo instalador geral.
- Removidos os arquivos de importação de Pessoal, Frota legada e Patrimônio inicial.
- Removidos os pacotes Base64 de dados legados embutidos no código.
- Atualizados testes e documentação para impedir retorno de importadores e instaladores específicos.
- Produção permanece sem alteração.
