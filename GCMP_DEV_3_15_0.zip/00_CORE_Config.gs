/**
 * Configurações centrais da Intranet de Recursos Institucionais.
 * IDs e segredos são armazenados em PropertiesService pelo 02_SCHEMA_Installer.gs.
 */
const APP_CONFIG = Object.freeze({
  NAME: 'Intranet de Recursos Institucionais',
  SHORT_NAME: 'Intranet Recursos',
  VERSION: '3.15.0',
  ENVIRONMENT: 'DEVELOPMENT',
  TIME_ZONE: 'America/Sao_Paulo',
  LOCALE: 'pt-BR',
  DEFAULT_SESSION_HOURS: 6,
  DEFAULT_IDLE_MINUTES: 60,
  DEFAULT_RECOVERY_MINUTES: 15,
  DEFAULT_MAX_LOGIN_ATTEMPTS: 5,
  DEFAULT_LOCK_MINUTES: 15,
  PASSWORD_MIN_LENGTH: 8,
  MAX_UPLOAD_BYTES: 5 * 1024 * 1024,
  MASP_DISPLAY_PATTERN: '000000-00',
  PROPERTY_KEYS: Object.freeze({
    INSTALLED: 'APP_INSTALLED',
    ROOT_FOLDER_ID: 'ROOT_FOLDER_ID',
    CONFIG_FOLDER_ID: 'CONFIG_FOLDER_ID',
    DB_CONFIG: 'DB_CONFIG_ID',
    DB_PERSONNEL: 'DB_PERSONNEL_ID',
    DB_ASSETS: 'DB_ASSETS_ID',
    DB_VEHICLES: 'DB_VEHICLES_ID',
    DB_DOCUMENTS: 'DB_DOCUMENTS_ID',
    DB_REWARDS: 'DB_REWARDS_ID',
    PASSWORD_PEPPER: 'PASSWORD_PEPPER'
  }),
  DATABASES: Object.freeze({
    CONFIG: 'DB_CONFIG',
    PERSONNEL: 'DB_PERSONNEL',
    ASSETS: 'DB_ASSETS',
    VEHICLES: 'DB_VEHICLES',
    DOCUMENTS: 'DB_DOCUMENTS',
    REWARDS: 'DB_REWARDS'
  }),
  STATUS: Object.freeze({
    ACTIVE: 'ATIVO',
    INACTIVE: 'INATIVO',
    BLOCKED: 'BLOQUEADO',
    AWAY: 'AFASTADO'
  })
});

const DEVELOPMENT_CONFIG = Object.freeze({
  ROOT_FOLDER_ID: '1_ertpqhYvpn0Mai9YEkpOlDN0HWiO0P1',
  CONFIG_FOLDER_ID: '1Z0oNaOIDsoMiQURvZOgqSD2a2hmGBpOF',
  DB_CONFIG_ID: '1yerhrcwEqY5PE0VHWXwT0CU6JejoYG5IEWqMdd5Q65Q',
  DB_PERSONNEL_ID: '13QxsON-OvTKVYXobDsR25smbVMsGDDZZVeqLaSIKQVk',
  DB_ASSETS_ID: '12KitE1cZDYbFbNxFK1lyTw9xEuMlzgGYrSCATTM4G9s',
  DB_VEHICLES_ID: '1qTV82EFbbV-YrGxHBhrIb7pmjGsDooeRGIQDt23hqf4',
  DB_DOCUMENTS_ID: '1GahWHs6G3VL9RC2AB91sRlOcoiFeEukZJQbVWOPeKIs',
  DB_REWARDS_ID: '1eOCVbh2R2NgjmJOS9FvOuuGeeiW3ZgXqm57TYbyNr6Q',
  FROTA_SPREADSHEET_ID: '171Kew8XdzZvBCxohD-buLQui_5ylKul0cVos-YZU3J0',
  FROTA_ROOT_FOLDER_ID: '169rQxF7JsCFtG6ercO0oKmfljUb1oYLK',
  BACKUP_FOLDER_ID: '1sDk4hR8_n24NbC5WXcMXAthzHf-tXeDt'
});

const MODULE_DEFINITIONS = Object.freeze([
  { id: 'dashboard', label: 'Início', icon: 'home', permission: null },
  { id: 'usuarios', label: 'Usuários', icon: 'users', permission: 'usuarios.visualizar' },
  { id: 'pessoal', label: 'Pessoal', icon: 'badge', permission: 'pessoal.visualizar' },
  { id: 'patrimonio', label: 'Patrimônio e Cautelas', icon: 'inventory', permission: 'PATRIMONIO_VISUALIZAR' },
  { id: 'viaturas', label: 'Frota', icon: 'car', permission: 'FROTA_ACESSAR' },
  { id: 'documentos', label: 'Documentos', icon: 'folder', permission: 'documentos.visualizar' },
  { id: 'recompensas', label: 'Recompensas', icon: 'award', permission: 'recompensas.visualizar' },
  { id: 'perfil', label: 'Minha Conta', icon: 'profile', permission: null },
  { id: 'configuracoes', label: 'Administração', icon: 'settings', permission: 'configuracoes.gerenciar' }
]);

function getScriptProperties_() {
  return PropertiesService.getScriptProperties();
}

function getProperty_(key, required) {
  const forced = APP_CONFIG.ENVIRONMENT === 'DEVELOPMENT' && Object.prototype.hasOwnProperty.call(DEVELOPMENT_CONFIG, key)
    ? DEVELOPMENT_CONFIG[key]
    : '';
  const value = forced || getScriptProperties_().getProperty(key);
  if (required && !value) {
    throw appError_('APP_NOT_INSTALLED', 'O sistema ainda não foi instalado ou está com configuração incompleta.');
  }
  return value || '';
}

function getRuntimeConfig_(key, fallback) {
  try {
    const row = repositoryFindOne_(APP_CONFIG.DATABASES.CONFIG, 'CONFIGURACOES', 'CHAVE', key);
    return row && row.VALOR !== '' ? row.VALOR : fallback;
  } catch (error) {
    return fallback;
  }
}

function getRuntimeNumber_(key, fallback) {
  const parsed = Number(getRuntimeConfig_(key, fallback));
  return Number.isFinite(parsed) ? parsed : fallback;
}

function getRuntimeBoolean_(key, fallback) {
  const value = String(getRuntimeConfig_(key, fallback)).toLowerCase();
  if (['true', '1', 'sim', 'yes'].indexOf(value) >= 0) return true;
  if (['false', '0', 'nao', 'não', 'no'].indexOf(value) >= 0) return false;
  return Boolean(fallback);
}
