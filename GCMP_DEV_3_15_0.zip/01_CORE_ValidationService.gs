/** Validações de integridade e entrada. */

function requireFields_(payload, fields) {
  const missing = fields.filter(function (field) {
    const value = payload ? payload[field] : null;
    return value === undefined || value === null || normalizeText_(value) === '';
  });
  if (missing.length) {
    throw appError_('VALIDATION_ERROR', 'Preencha todos os campos obrigatórios.', { fields: missing });
  }
}

function validateEmail_(email, required) {
  const value = normalizeText_(email).toLowerCase();
  if (!value && !required) return '';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) throw appError_('INVALID_EMAIL', 'Informe um e-mail válido.');
  return value;
}

function validateMasp_(masp) {
  const value = normalizeMasp_(masp);
  if (value.length !== 8) throw appError_('INVALID_MASP', 'Informe o MASP no padrão 000000-00.');
  return value;
}

function validateCpf_(cpf, required) {
  const value = normalizeCpf_(cpf);
  if (!value && !required) return '';
  if (value.length !== 11 || /^(\d)\1{10}$/.test(value)) throw appError_('INVALID_CPF', 'Informe um CPF válido.');
  let sum = 0;
  for (let i = 0; i < 9; i += 1) sum += Number(value.charAt(i)) * (10 - i);
  let digit = 11 - (sum % 11);
  if (digit >= 10) digit = 0;
  if (digit !== Number(value.charAt(9))) throw appError_('INVALID_CPF', 'Informe um CPF válido.');
  sum = 0;
  for (let i = 0; i < 10; i += 1) sum += Number(value.charAt(i)) * (11 - i);
  digit = 11 - (sum % 11);
  if (digit >= 10) digit = 0;
  if (digit !== Number(value.charAt(10))) throw appError_('INVALID_CPF', 'Informe um CPF válido.');
  return value;
}

function validateUnique_(databaseKey, sheetName, field, value, currentIdField, currentId, normalizer) {
  if (value === '' || value === null || value === undefined) return;
  const normalize = normalizer || function (input) { return normalizeUpper_(input); };
  const duplicate = repositoryFindOne_(databaseKey, sheetName, field, value, normalize);
  if (duplicate && (!currentIdField || String(duplicate[currentIdField]) !== String(currentId || ''))) {
    throw appError_('DUPLICATE', 'Já existe um registro com o mesmo valor no campo ' + field + '.', { field: field });
  }
}

function validatePositiveNumber_(value, label, allowZero) {
  const number = Number(value);
  if (!Number.isFinite(number) || number < 0 || (!allowZero && number === 0)) {
    throw appError_('INVALID_NUMBER', (label || 'Valor') + ' deve ser um número válido.');
  }
  return number;
}

function validateDateOrder_(start, end, message) {
  if (start && end && toDate_(end).getTime() < toDate_(start).getTime()) {
    throw appError_('INVALID_DATE_ORDER', message || 'A data final não pode ser anterior à data inicial.');
  }
}

function validateStatus_(value, allowed, label) {
  const normalized = normalizeUpper_(value);
  if (allowed.indexOf(normalized) < 0) throw appError_('INVALID_STATUS', (label || 'Situação') + ' inválida.');
  return normalized;
}
